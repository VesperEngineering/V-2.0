# Fama-MacBeth Regression Results (2026-07-07)

**Script**: `scripts/fama_macbeth.py`
**Method**: Two-pass cross-sectional regression with Newey-West standard errors (4 lags)
**Period**: 2005-2026, 21d forward horizon, 169 rebalance dates
**Factors tested**: intraday_range, sp500_technical, mean_reversion, amihud, size, beta, massive

## Results

| Factor | Coefficient | NW t-stat | % Positive | Significant? |
|---|---|---|---|---|
| intraday_range | +0.0064 | **+4.10** | 59% | YES (p<0.001) |
| size | -0.0019 | **-2.61** | 41% | YES (small-cap premium) |
| mean_reversion | +0.0013 | **+2.00** | 55% | Borderline |
| sp500_technical | +0.0045 | +0.81 | 57% | NO |
| amihud | -0.0054 | -1.78 | 41% | NO |
| massive | -0.0040 | -0.73 | 46% | NO |

## Key Findings

- **intraday_range is the only factor with t > 3.0.** Statistically significant at p < 0.001.
- **sp500_technical has t = 0.81.** This was our anchor factor at weight 1.0. FM says it contributes nothing once intraday_range is in the model.
- **size (small-cap premium) is significant** (t = -2.61) despite being removed by the factor optimizer. FM and optimizer disagree on this factor.
- **Mean cross-sectional R² = -0.13.** Noise dominates at daily frequency — expected for factor models.
- **3 of 7 factors are statistically significant.** Only intraday_range survives with strong confidence.

## Live IC Tracker — 21d Horizon, Not 1d

The live IC tracker (`app/services/live_ic_tracker.py`) originally measured 1d forward returns. **1d is too noisy** — even validated signals (intraday_range IC IR +0.117 at 21d) look like noise (IR NaN) at 1d. The fix: switch to 21d forward horizon matching the backtest. The tracker now uses `date_idx[snap_date] + 21` to find forward returns from the OHLCV DB.

**Timeline**: first IC reading ~21 trading days after the first pipeline snapshot (~August 5 for July 6 start). Signal stabilizes after ~10 observations, reliable after ~20.

**Simulation**: `scripts/sim_live_ic.py` replays the daily IC cycle across 2005-2026 to show what the dashboard will look like historically.

## Alpaca Fractional Share Sell Fix

When selling positions not in the target basket, use **QTY orders** with exact available share count from `p.qty_available`, NOT notional orders. Notional orders get converted to share quantities by Alpaca, introducing sub-penny rounding mismatches (requested 163.978441455 vs available 163.827247309). 

```python
# Correct: QTY order using exact available shares
req = MarketOrderRequest(
    symbol=ticker,
    qty=round(qty, 4),
    side=OrderSide.SELL,
    time_in_force=TimeInForce.DAY,
)
```

`_current_positions()` returns `{ticker: (market_value, qty_available)}` tuples. The buy/trim loop unpacks: `entry = current.get(ticker); existing = entry[0] if entry else 0.0`.

## User Preference: Discuss Before Coding

**When the user asks a question, answer the question — don't jump to code immediately.** The user said "I just asked the question, didn't want you to do anything yet" when code was written in response to a conversational question. Path: discuss → confirm → then act. Exceptions: explicit directives like "Fire!", "Okay, begin", "Do it."

## FM vs Optimizer vs IC Analysis

| Method | Best factors | Limitation |
|---|---|---|
| Rank IC | sp500_technical, amihud | Doesn't control for multicollinearity |
| Optimizer | intraday_range, sp500_technical, mean_reversion | Inflated Sharpe (0.93 vs actual 0.57) |
| **Fama-MacBeth** | **intraday_range, size, mean_reversion** | **Gold standard** — heteroskedasticity- and autocorrelation-robust |

## When to Run

Run `scripts/fama_macbeth.py` after ANY factor change. It's the final arbiter of statistical significance. If a factor has |t| < 2.0 and the optimizer says it helps, trust FM — drop the factor.

## Optimizer Inflation Pitfall

The factor optimizer (`scripts/factor_optimizer.py`) inflated Sharpe by z-scoring sub-signals within each backtest step (a form of look-ahead bias). The actual backtest (`scripts/vesper_backtest_v3.py`) produced Sharpe 0.57 for the 3-factor kernel, not 0.93. **Never report optimizer Sharpe numbers without comparing against the actual backtest.** The optimizer is useful for RANKING factors (which is best, which dilutes) but NOT for absolute Sharpe estimates.
