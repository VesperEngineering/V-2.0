# Vesper Daily Operations & Morning Briefing

## Overview
After the factor pipeline runs (scores at 02:00 UTC, basket at 02:30, news at 09:00), the daily morning briefing compiles key outputs into a scan-ready summary. This reference documents the data sources, file layout, and interpretation rules.

## Project Layout
All paths below are relative to `/d/vesper/` (WSL) or `D:\vesper` (Windows).

| Component | Path | Format |
|---|---|---|
| Factor scores | `vesper_data/factor_scores_YYYYMMDD.json` | JSON |
| Nova picks history | `vesper_data/nova_picks.json` | JSON dict: `{"DATE": [tickers]}` |
| Factor vs Nova comparison | `artifacts/evals/factor_vs_nova_YYYYMMDD.{json,md}` | JSON + MD |
| Factor basket | `artifacts/evals/vesper_factor_basket_YYYYMMDD.md` | MD |
| No-order report | `artifacts/evals/daily_no_order_report_YYYYMMDD_manual.md` | MD |
| IC analysis | `artifacts/evals/factor_ic_analysis_YYYYMMDD.md` | MD |

## Morning Briefing Composition

### 1. Status Section
- **Date**: extract `date` field from the latest `factor_scores_YYYYMMDD.json`
- **Scored count**: `scored_count` / `universe_size`
- **Freshness**: compare `timestamp` field to current time. If `> 48 hours`, flag as stale.

### 2. Top 5 Scores
- Read `scored` array (sorted descending by `score`)
- Take first 5 entries, format as: `{rank}. **{ticker}** — {score:.3f}`

### 3. Nova Basket
- Source from the latest `daily_no_order_report_YYYYMMDD_manual.md`:
  - Look for the "Candidate Selection" table rows
  - Each row: `` | `TICKER` | weight% | weight% | delta% | notes ``
  - Strip backticks, uppercase
- Fallback: read the most recent entry in `nova_picks.json`

### 4. Factor Basket
- Source from the latest `vesper_factor_basket_YYYYMMDD.md`
- Table rows: `| rank | TICKER |`

### 5. Basket Comparison
- Compare the two baskets as **sets** (ignore order/ranking)
- If identical → "ℹ️ Neither model found an advantage"
- If different → list tickers in one but not the other

### 6. Factor vs Nova Signal
- Read `factor_vs_nova_YYYYMMDD.md`:
  - `recommendation` field: `nova_outperforms`, `factor_outperforms`, or `hybrid`
  - Sharpe values (both negative = bearish period)
  - Disagreement win rate and number of disagreement periods

### 7. Alerts Checklist
| Condition | Output |
|---|---|
| No scores file exists | ⚠️ No scores found — run Compute Scores |
| Scores >48h old | ⚠️ Scores are stale — run Compute Scores |
| Baskets identical | ℹ️ Neither model found an advantage |
| Baskets differ | List differences explicitly |
| Last NOHR is stale (>7d) | ⚠️ No recent no-order report found |

### 8. Recommendation
- **Nothing to do** — scores fresh, baskets aligned, no divergence
- **Run Re-rank** — baskets differ materially and factor model shows advantage
- **Run Compute Scores** — missing or stale scores

## File Freshness Check
```bash
# Scores (latest file timestamp)
ls -la /d/vesper/vesper_data/factor_scores_*.json

# Evals freshness
ls -lat /d/vesper/artifacts/evals/factor_vs_nova_*.md | head -3
ls -lat /d/vesper/artifacts/evals/vesper_factor_basket_*.md | head -3
```

## Historical Benchmarks (as of Jul 2026)
- Factor Sharpe: —5.26 (10d horizon)
- Nova Sharpe: —3.85 (10d horizon)
- Factor beat rate vs Nova: 60% (5 disagreement periods over 504 dates)
- Mean overlap when models disagree: ~9%
- Both models have negative Sharpe in recent period — overall market is bearish on this timescale