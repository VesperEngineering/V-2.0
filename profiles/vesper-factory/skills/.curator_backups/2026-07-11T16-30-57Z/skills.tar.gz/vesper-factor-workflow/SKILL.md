---
name: vesper-factor-workflow
description: End-to-end workflow for building, evaluating, and deploying factor-based alpha signals in Vesper.
---

# Vesper Factor Workflow

Implementation and execution of factor-based investment strategies within the Vesper quantitative trading system. Covers factor development, evaluation (Fama-MacBeth), deployment via the daily pipeline, and the strategic decision of when to stop building factors and focus on portfolio construction.

## Project Conventions

- Discover the active CLI contract from tracked launchers, tests, fixtures, receipts, and production call sites before changing names. Never assume a partial `deploy/nova.py` ↔ `deploy/vesper.py` migration is complete; either retain the established contract or migrate every dependent surface atomically.
- Treat `NOVA_*` ↔ `VESPER_*` environment-variable renames the same way: inspect actual consumers and fixtures instead of applying a blind global replacement.
- Discover the active scheduler from `docs/STATUS.md`, Windows Task Scheduler, `scheduler/jobs.json`, and running processes before changing automation. Do not assume the daemon, Windows fallback, or Hermes cron is currently authoritative.
- Brand cleanup is complete only when code, tests, fixtures, launchers, receipts, documentation, and governance agree. A mixed identity is worse than retaining the older established contract temporarily.
- Shared DB helper: `app/factors/db.py` (open_ohlcv_db, fetch_recent_dates, fetch_ohlcv_rows, build_ohlcv_panel) — factor calculations should source through this helper and use parameterized SQL. A small read-only admission query such as `MAX(date)` is acceptable when isolated, tested, and tied to the exact active database.
- Do not hardcode the current Hermes model/provider in this engineering workflow. Inspect the active runtime/config when model choice matters; subscriptions, aliases, and fallback chains change independently of Vesper code.

## Current Registry: Inspect, Do Not Memorize

The registry, weights, FM evidence, and factor count change quickly. Do not trust a static table in this skill. Before any scoring, governance, or deployment task, inspect:

1. `app/factors/registry.py` for registered implementations;
2. `scripts/run_all_factors.py` for explicit live weights and core-factor admission;
3. `artifacts/evals/fama_macbeth_*.json` for the latest FM evidence;
4. `docs/STATUS.md` and the current worktree diff for operational truth;
5. `references/current-registry.md` only as a dated snapshot, never as higher authority than code.

Fail closed if a registered factor lacks an explicit weight. Never add a fallback live weight such as `weights.get(name, 0.5)`: a newly registered factor must not silently enter the production blend. Successful factor payloads must be non-empty, numeric, and finite; declared core factors must all be present before publication.

Apply the FM governance rule to the current evidence: |t| > 2.0 is a keep candidate, |t| < 1.5 is a kill candidate, and borderline factors require an explicit strategy decision. Do not preserve stale counts or weights in operational docs.

## Factor Building Pattern

All OHLCV-sourced factors follow the same pattern using `app/factors/db.py`:

```python
from app.factors.db import fetch_ohlcv_rows, fetch_recent_dates, open_ohlcv_db

class MyFactor(BaseFactor):
    name = "my_factor"
    required_data: list[str] = []

    def _compute(self, *, root=".", date_stamp=None, universe=None, **kwargs):
        conn = open_ohlcv_db(root / OHLCV_DB)
        try:
            dates = fetch_recent_dates(conn, limit=LOOKBACK)
            rows = fetch_ohlcv_rows(conn, dates, extras=("high", "low", "open"))
        finally:
            conn.close()
        # ... compute signal from rows ...
        return FactorResult(scores=self.zscore(raw), metadata={...})
```

Never use `.format()` or f-strings for SQL. Always use `?` parameterized queries via `fetch_ohlcv_rows`.

### Interaction Factors

Factors that combine two parent factors (e.g., `gv_cb_interaction`) run both parents internally and multiply their cross-sectional z-scores. The product is then z-scored again. This pattern captured synergistic IC IR (+0.144) that beat either parent alone.

## Factor Evaluation: Fama-MacBeth

FM regression with Newey-West t-stats is the **gold standard** for factor validation. Overrides solo IC, optimizer Sharpe, and intuition.

- |t| > 2.0 = keep, |t| < 1.5 = kill
- Run on 2005-2026 data, 21d forward horizon
- Re-run FM after any factor addition or removal
- Factors that look great in solo IC but fail when controlled for other factors → kill (amihud: solo IC great, FM t=-1.75)

### Live IC Tracker

For factors that can't be FM-validated historically (real-time data sources like SEC Form 4, normalized DB with data gaps), the live IC tracker validates them in production. Rolling 21d forward IC IR. If it drops below 0.02, alert.

## Historical Strategy Reconstruction Audits

Before using the live factor-to-basket pipeline as a historical baseline—especially for a stop-loss backtest—perform a source-level reconstruction audit:

1. Snapshot HEAD plus staged, unstaged, and untracked state. Do not assume generated artifacts match the current dirty worktree.
2. Render and syntax-check any Python passed to subprocesses; parent-file syntax checks do not validate generated child code.
3. Compare live and FM implementations factor by factor: formula, sign, lookback, z-score convention, missing values, and universe.
4. Prove that `date_stamp` changes the data cutoff. A historical runner must query `date <= as_of_date`; a date used only in filenames is not point-in-time behavior.
5. Explicitly order rolling inputs by ticker/date. Never rely on SQLite's observed index order.
6. Use complete-case exposure rows for a frozen historical kernel. Ticker-specific available-weight denominators let sparse factors dominate and make cross-sectional scores incomparable.
7. Require point-in-time membership and sectors plus split-adjusted OHLCV. A current-constituent backfill is survivorship-biased, and raw split jumps create false returns, ATR, gaps, and stop triggers.
8. Match signal time to execution time: close-`t` inputs imply next-session execution, not a same-close fill.
9. Reconcile displayed basket weights with actual cash reserve and rebalance code.
10. Freeze and run the no-stop strategy before adding the stop overlay; keep selections, costs, and execution assumptions identical.

Call a four-name basket drawn from four winning sectors **sector-diversified**, not fully sector-neutral against a benchmark. Use unrounded scores and a deterministic ticker tie-break for replay.

See `references/factor-basket-stop-backtest-audit.md` for the full checklist, defensible reconstruction pattern, and stop-fill rules. See `references/historical-stop-data-source-audit-20260710.md` for the dated concrete SQLite paths, schemas, observed coverage, canonical adjusted-row join pattern, exact frozen kernel, and blockers discovered in the 2026-07-10 read-only source audit. See `references/backtest-promotion-and-symbol-identity.md` for the backtest→shadow→paper→live promotion ladder, auditable gate fields, ticker-reuse/rename handling, fail-closed held-price rules, and the required return-tail sanity check. See `references/position-risk-backtest-accounting.md` for initial/terminal equity accounting, two-pass cash-safe rebalancing, impossible new-entry fill prevention, non-widening campaign stops, consumed-path warm-up rules, split-adjusted execution versus dividend return accounting, effective-dated corporate-action identity, holding-horizon, missing-session, configuration-admission, artifact-hash, and numeric promotion-gate invariants. See `references/position-risk-provenance-and-reconstruction-audit.md` for dual executable/return price bases, formula/warmup/ddof parity, moving-worktree artifact identity, sector-label honesty, and complete economic-gate checks. See `references/position-risk-survivor-diagnostic-20260710.md` for the first survivor-cohort comparison, its independent-audit invalidation, the code-hashed repaired rerun awaiting independent verification, and the rule against citing provisional stop results after simulator/accounting defects are found. See `references/gap-intraday-event-ablation-20260710.md` for the selected-position 1/5/10-session recovery method, frozen opening-gap-versus-intraday structural ablation, provisional results, and the explicit invalidation boundary created by entry-ordering and GOOG/GOOGL identity defects. See `references/survivor-cohort-stop-diagnostic-review-20260710.md` for the later impossible new-entry breaker-fill reproduction, GOOG/GOOGL corporate-action identity failure, artifact/source drift checks, suspicious-metric probes, and bounded fixed-parameter replication rule.

## When to STOP Building Factors

**Critical strategic lesson (2026-07-09):** The user was about to keep adding factors when the real bottleneck is portfolio construction and risk management. Of 16+ factors built, only 2 survived FM (88% kill rate). Every new factor has ~1/8 chance of making the blend.

The alpha ceiling is NOT more factors. It's the layers above them:
1. **Risk management** — per-position stop-loss (see `references/stop-loss-design.md`), sector exposure limits, beta-adjusted exposure, drawdown throttle
2. **Portfolio construction** — shrinkage optimizer, turnover penalty, correlation-aware sizing
3. **Signal combination** — rolling FM reweight, ensemble with disagreement penalty, IC-weighted combination
4. **Execution** — cost-aware rebalance, VWAP execution, stale data guard

Before building factor #N+1, ask: "Is the portfolio construction layer built?" If no, build that first. The operator agreed with this assessment.

## Key Rules (Don't Revisit)

- **FM regression with Newey-West is gold standard.** |t| > 2.0 = keep, |t| < 1.5 = kill.
- **Kill dilutive factors.** Don't leave at weight 0.0 — remove from registry and delete the file.
- **No factors work at 1d horizon.** Edge is 10–21d cross-sectional ranking.
- **Rank-based z-score for microstructure.** Raw z-scores useless for Amihud/turnover/VWAP.
- **Aggressive culling beats more factors.** 3 beat 11. FM-proven.
- **No drawdown circuit breakers.** Tested — sell at the bottom, miss recoveries. Regime filters only. See `references/drawdown-circuit-breaker-pitfall.md`.
- **Per-position stop-loss is a research candidate, not an established improvement.** The proposed three-tier design (ATR hard stop / time-based exit / gap breaker) is documented in `references/stop-loss-design.md`, but model agreement and unit tests do not establish portfolio benefit. Require a clean matched historical diagnostic and the promotion ladder in `references/backtest-promotion-and-symbol-identity.md`; reject or demote any policy that fails its pre-registered economic gate. Full design draft: `D:/vesper/docs/STOP_LOSS_DESIGN.md`. Production risk management still depends heavily on partial fills, broker outages, reconciliation, corporate actions, and stale-order handling. **Before backtesting, reconcile and pre-register the stop parameters:** the condensed reference uses ATR(14) with a 12% floor, while repository drafts may still say ATR(20) with an 8% floor. Never choose between them after seeing results; freeze one as canonical and treat the other as a sensitivity.
- **Live IC tracker validates what FM can't.** market_micro and sec_insider_v2 prove themselves here.

## Daily Pipeline: Discover Schedule, Enforce Invariants

Do not preserve a hardcoded schedule table here; scheduler ownership and times are operational state. Read `docs/STATUS.md`, inspect the configured task actions/triggers, and verify the actual running process before changing anything.

### Reconcile authority before freshness can unblock execution

A successful ingest→score→basket run can turn a previously harmless failing order task into an active order path. Before describing restored freshness as operational readiness, compare all three surfaces:

1. **Board authority:** `PROJECT_ADVANCEMENT.md` execution scope, selected basket, account approval, and the exact meaning of any bounded paper lane.
2. **Scheduler action:** the actual Windows/Hermes task command and whether it invokes preview, evidence-only, or order-submitting code.
3. **Production entry point:** trace the called script through `main()` to prove whether it only validates/reports or actually reaches broker reconciliation/submission.

Fail closed on any mismatch. In particular, `paper_only` or `bounded_paper_order_evidence_only` does not automatically authorize a generic factor-basket rebalance when the board names a different accepted-paper basket. Do not use an order-bearing task as a verification probe. Present one clear recommendation—normally pause the task or convert it to explicit no-submit preview—and obtain the user's decision before mutating scheduler state. Restoring data freshness, validating a basket, and refreshing the GUI must never silently widen execution authority.

For retained-context verification, a manually triggered **non-order** Windows factor task can prove that its stored principal, interpreter, cwd, and wrapper work; still observe the next natural cycle before claiming schedule reliability. Verify its `Last Result`, wrapper log, DB max session, score provenance, basket provenance, and dashboard payload. An order-bearing rebalance task must be observed naturally or tested through a dedicated no-submit path, never manually duplicated.

See `references/freshness-and-execution-authority-reconciliation.md` for the concise verification and escalation checklist. When the safe decision is conversion rather than continued execution, use `references/scheduler-preview-conversion.md` for the dedicated no-submit entry point, truthful task rename, old-route removal, retained-context test, broker-zero-order proof, dashboard update, and natural-cycle follow-up pattern.

### Audit filesystem freshness and weekend task behavior correctly

Do not infer source freshness from Windows Explorer's top-level folder `Date modified`: overwriting an existing child file or SQLite database may leave the directory timestamp unchanged. Prove whether `data` is a junction to `vesper_data`, find the newest file recursively, query the canonical database's admitted source/session date and latest-session row count, and reconcile those results with wrapper logs and downstream provenance.

Classify each data directory by its current writer, registry entry, and authoritative scheduler action before calling it stale. Production caches, periodic collectors, historical archives, one-time pilots, research artifacts, and retired factor outputs can coexist under `vesper_data`; dashboard display references do not prove an active collector.

A Windows task scheduled `Daily` launches on weekends unless its action suppresses them. The pipeline can then resolve the prior XNYS session (normally Friday on Saturday/Sunday). A weekend natural run is valid evidence for task launch and market-calendar handling, but not complete proof of normal weekday timing. Always report `Interactive only`/logout and battery restrictions, and distinguish an on-schedule natural run from a manual or out-of-window success. See `references/data-directory-freshness-and-weekend-scheduler.md` for the complete audit and reporting checklist.

Regardless of scheduler, enforce this chain:

1. Ingest completes through the immediately preceding XNYS session.
2. Factor scoring proves the active database's max date equals that session, validates explicit weights and required core results, and writes source provenance.
3. Basket generation consumes only the exact admitted score date, repeats the provenance marker, and enforces the frozen basket contract.
4. Dashboard refresh runs only after score and basket success.
5. Paper rebalance consumes only the exact prior-session basket within a freshness window derived from the real scheduled gap and upstream runtime.

The artifact wrapper must stop on first failure, propagate the exit code, bound each step with a timeout, terminate the full descendant process tree before releasing its singleton lock, and prevent overlap with an OS-level singleton lock. `--dry-run` proves file/prerequisite presence only. Never describe it as data or economic readiness.

The paper connector must not be invoked for generic verification. It requires explicit execution scope and a crash-recoverable ownership model: a process lock, basket digest, atomic durable run state, pre-submission deterministic `client_order_id`, recovery by broker/client ID, no global cancellation, fractionable/tradable admission for notional orders, reductions confirmed filled before buys, refreshed positions, terminal buy-fill verification, owned-order cancellation/confirmation on failure, unique receipts, and a completed-run no-op. A helper implementation is unfinished until the actual production entry point routes through it and the post-integration tests plus fresh independent review pass. To answer “did it trade?”, query same-day paper-broker order history read-only and cross-check owned state/receipts and task logs; a failed task or missing receipt alone is not definitive because a process can fail after submission.

When the GUI and internal scripts disagree, debug them as separate layers: data pipeline, server/port owner, browser assets, scheduler, and broker evidence. Communicate the result in the same order with a plain status matrix—`orders today`, `data pipeline`, `GUI runtime`, `scheduler/authority`—before technical detail. Never use a global label such as `BLOCKED` without naming the blocked layer; a healthy data pipeline can coexist with a deliberately blocked order path. Prove every port-8080 listener and the served API contract before touching HTML. A shadow `0.0.0.0` server can coexist with the authoritative `127.0.0.1` listener, and a generic `pythonw.exe` launcher check can preserve the wrong deployment. See `references/dashboard-debugging-pitfalls.md` for the runtime-identity, launcher, no-order, and browser verification procedure. See `references/dashboard-runtime-authority.md` for the reusable signed-status, loopback binding, singleton tray, duplicate-launch verification, and shadow-server recovery pattern.

See `references/fail-closed-morning-artifacts-and-paper-orders.md` for the complete source-date, exchange-timezone, artifact-provenance, process-tree timeout, schedule-window, broker-state, logging, and verification pattern.

## Factor Weight Configuration

Weights live in `scripts/run_all_factors.py` in the `FACTOR_WEIGHTS` dict. The `run()` function blends factors using weighted average, then sorts by combined score. Top 4 go to the sector-neutral basket.

After any weight change:
1. Re-run FM regression to validate
2. Update STATUS.md
3. Verify pipeline runs clean the next morning

## Data Sources

- **Massive OHLCV** (primary): `vesper_data/massive/sp500/sp500_ohlcv.sqlite` — 500 tickers, 2003-2026, daily bars. Free via S3.
- **Massive normalized (inspect exact file):** the small `vesper_data/massive/normalized/day_aggs_coverage_expanded.sqlite` is sparse and unsuitable for long-window history, but cumulative files such as `day_aggs_coverage_expanded_2026.sqlite` can contain the full 2003–2026 raw panel across tens of thousands of symbols. Never generalize the sparse-file gap to the cumulative snapshots; verify schema, row count, symbol count, min/max dates, and adjustment basis on the exact path before choosing a source.
- **SEC EDGAR**: Form 4 (insider trades), companyfacts (fundamentals). Free API.
- **Wikipedia**: Page view counts. Free API.
- **FRED**: Yield curve, CPI, unemployment. Free API.
- **FinViz/RSS**: News sentiment. Free scrape.

## Pitfalls

- **A green process is not admitted data** — an exit code of zero proves mechanics only. Verify the actual source max date, exchange session, embedded artifact provenance, required factors, and downstream contract before calling a run ready.
- **Independent reviews are time-stamped snapshots** — if files change after dispatch, reconcile findings against current files and dispatch a fresh final review. A pending or stale review is not approval.
- **Dirty worktrees hide review surfaces** — inspect staged, unstaged, and untracked files explicitly. Treat untracked scoped files as wholly new; do not stage, stash, reset, or rewrite unrelated work just to simplify review.
- **Scheduler times and freshness limits form one contract** — calculate the real producer-to-consumer gap before setting the mtime bound, and use exact source-session provenance as the primary guard.
- **Broker safety is lifecycle safety** — symbol syntax and successful submission are insufficient. Validate asset identity/tradability, preserve unrelated open orders, require terminal fills in reduction-before-buy phases, and fail on unknown state.
- **`daily_factor_scores.py` was deleted** — it referenced old Nova/entropy/hurst concepts. `scripts/run_all_factors.py` is the current factor runner.
- **CLI/brand migrations must be atomic** — trace production call sites, tests, fixtures, launchers, receipts, documentation, governance, and environment-variable consumers. If they disagree, preserve the established executable contract until the whole migration can be verified together; never infer completion from the presence of a newer duplicate entry point.
- **Do not conflate normalized snapshots** — the small `day_aggs_coverage_expanded.sqlite` has the historical gap that blocks long-window validation, while dated cumulative snapshots (for example `day_aggs_coverage_expanded_2026.sqlite`) may hold full 2003–2026 raw history. Query the exact file before declaring a factor historically untestable; then separately verify adjustment, membership, sector, and publication-lag requirements.
- **Subprocess factor execution** — `run_all_factors.py` spawns a Python subprocess per factor for timeout isolation. This is expensive but prevents one hung factor from blocking the pipeline.
- **Ticker strings are not security identities** — renames and ticker reuse require effective-dated normalization. After normalization, assert unique security/date rows, fail if a held security lacks a price, and inspect extreme portfolio-return days before judging economics. See `references/backtest-promotion-and-symbol-identity.md`.
- **Model comparisons are design input, not validation** — model consensus can improve failure-mode coverage, but only historical, shadow, paper, and operational evidence can promote a risk policy. Keep provider/model setup out of this Vesper workflow because aliases and subscriptions change.
