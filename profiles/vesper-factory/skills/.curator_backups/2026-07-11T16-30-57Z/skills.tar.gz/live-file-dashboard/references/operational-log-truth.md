# Operational Log Truth in Live Dashboards

Use this reference when a dashboard exposes logs and status for a bursty pipeline with local inference.

## Historical versus active failures

A log tail or persisted analysis can continue showing failures after a runtime restart and successful repair. Always display or investigate these as timestamped historical records, not current health.

Recommended sequence:

1. Capture the runtime restart timestamp or current log byte offset.
2. Count fresh queue-full, inference HTTP, parse, worker, and stream errors only after that boundary.
3. Show source-data freshness independently from dashboard refresh time.
4. Distinguish raw-event durability from analysis coverage: a bar can be journaled while downstream live analysis is skipped.
5. Keep issue state open until the original live workload (including indicator warm-up) runs without recurrence.

## Backpressure diagnostics

For burst arrivals feeding local LLM work:

- Quantify arrival burst size and sustained inference throughput.
- Probe the exact production endpoint/model/options, not merely service health.
- A successful but slow request can still be the root cause of queue saturation.
- For current Ollama Qwen APIs, thinking control is a top-level `"think": false` field; putting `enable_thinking` inside `options` may be ignored, consume the token budget as hidden reasoning, return empty response text, and stall the serial worker.

## Windows logging safety

Windows launchers may expose CP1252 consoles even when files use UTF-8. Decorative check/cross glyphs can trigger console `UnicodeEncodeError` while file logs look normal.

- Prefer ASCII operational labels: `ACCEPTED`, `REJECTED`, `BLOCKED`.
- Add a source-level regression that parses logger literals with `ast` and strictly encodes them as CP1252.
- Treat console logging failure as an observability defect; verify persistence and processing separately.
