#!/usr/bin/env python3
"""Dashboard data aggregator — reads Vesper data sources and outputs
dashboard_data.json consumable by the HTML frontend.

Usage: uv run python vesper-dashboard/aggregator.py
   or: python vesper-dashboard/aggregator.py
"""

from __future__ import annotations

import json
import os
import re
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any

# VESPER_ROOT: try env var, then common paths
_vesper_env = os.environ.get("VESPER_ROOT", "")
if _vesper_env:
    VESPER_ROOT = Path(_vesper_env)
else:
    # Try D:\vesper first, then parent of this script
    candidate = Path("D:/vesper")
    if candidate.exists():
        VESPER_ROOT = candidate
    else:
        VESPER_ROOT = Path(__file__).resolve().parent
        if VESPER_ROOT.name == "vesper-dashboard":
            VESPER_ROOT = VESPER_ROOT.parent

DATA_DIR = VESPER_ROOT / "data"
EVALS_DIR = VESPER_ROOT / "artifacts" / "evals"


def _latest_json(glob_pattern: str) -> Path | None:
    """Return the most recently modified JSON file matching the glob."""
    files = sorted(DATA_DIR.glob(glob_pattern), key=lambda p: p.stat().st_mtime, reverse=True)
    return files[0] if files else None


def _latest_md(directory: Path, glob_pattern: str) -> Path | None:
    """Return the most recently modified markdown file matching the glob."""
    files = sorted(directory.glob(glob_pattern), key=lambda p: p.stat().st_mtime, reverse=True)
    return files[0] if files else None


def _latest_md_skip_validation(directory: Path, glob_pattern: str) -> Path | None:
    """Latest markdown file matching glob, skipping _validation files."""
    files = sorted(directory.glob(glob_pattern), key=lambda p: p.stat().st_mtime, reverse=True)
    for f in files:
        if "_validation" not in f.stem:
            return f
    return None


def load_factor_leaders() -> dict[str, Any]:
    """Load top 10 factor leaders with detailed columns."""
    scores_file = _latest_json("factor_scores_*.json")
    if not scores_file:
        return {"error": "No factor_scores file found", "leaders": [], "date": None, "freshness": None}

    with open(scores_file, encoding="utf-8") as f:
        data = json.load(f)

    scored = data.get("scored", [])
    scored.sort(key=lambda x: -x["score"])

    leaders = []
    for i, item in enumerate(scored[:10]):
        details = item.get("details", {})
        leaders.append({
            "rank": i + 1,
            "ticker": item["ticker"],
            "score": round(item["score"], 4),
            "entropy": round(details.get("entropy", 0), 3),
            "hurst": round(details.get("hurst", 0), 3),
            "vol": round(details.get("realized_vol_z60_lag1", 0), 3),
            "sent": round(details.get("sentiment", 0), 3),
            "insider": round(details.get("insider", 0), 3),
        })

    mtime = datetime.fromtimestamp(scores_file.stat().st_mtime, tz=timezone.utc)
    age_hours = (datetime.now(timezone.utc) - mtime).total_seconds() / 3600

    return {
        "leaders": leaders,
        "date": data.get("date", ""),
        "scored_count": data.get("scored_count", len(scored)),
        "factor_features": data.get("factor_features", []),
        "freshness_hours": round(age_hours, 1),
        "is_stale": age_hours > 48,
    }


def get_market_status() -> str:
    """Determine if US market is currently open."""
    now_utc = datetime.now(timezone.utc)
    if now_utc.weekday() >= 5:
        return "CLOSED"
    market_open = now_utc.replace(hour=14, minute=30, second=0, microsecond=0)
    market_close = now_utc.replace(hour=21, minute=0, second=0, microsecond=0)
    if market_open <= now_utc <= market_close:
        return "OPEN"
    pre_market = now_utc.replace(hour=9, minute=0)
    if pre_market <= now_utc < market_open:
        return "PRE-MARKET"
    return "CLOSED"


def aggregate() -> dict[str, Any]:
    """Aggregate all dashboard data into a single dict. Extend with your own loaders."""
    now = datetime.now(timezone.utc)
    return {
        "generated_at": now.strftime("%Y-%m-%dT%H:%M:%SZ"),
        "last_update": now.strftime("%H:%M:%S") + " UTC",
        "market_status": get_market_status(),
        "mode": "PAPER",
        "system": "HEALTHY",
        "version": "v2.0.0",
        "factor_leaders": load_factor_leaders(),
        # Add more loaders here: load_selected_basket(), load_portfolio(), etc.
    }


def main():
    result = aggregate()
    output_path = VESPER_ROOT / "vesper-dashboard" / "dashboard_data.json"
    output_path.parent.mkdir(exist_ok=True)
    output_path.write_text(json.dumps(result, indent=2, default=str), encoding="utf-8")
    print(f"Wrote dashboard data to {output_path}")


if __name__ == "__main__":
    main()