# Read-only SQLite Operations Dashboard

Use this pattern when an operational dashboard must expose live SQLite/log state without creating a mutation surface.

## Architecture

- Standard-library `ThreadingHTTPServer` serves static SPA assets and `/api/status`.
- The API opens SQLite read-only in behavior: bounded `SELECT` queries only; no write endpoints.
- Effective configuration is reduced to an explicit allowlist. Never serialize the full config because it may contain credentials.
- Logs are decoded with replacement and capped to a small tail.
- Frontend refreshes only while visible (`document.hidden === false`).

## Safe startup sequence

1. Probe the intended port before launching.
2. If another named project owns it, do not terminate or replace that process.
3. Select the documented fallback port and report the exact URL.
4. Start the server as a tracked background process.
5. Probe `/api/status` and assert expected schema plus safety state before opening the browser.
6. Navigate through every sidebar view and inspect the rendered page visually.

A response from the intended port is not proof that the newly launched server owns it. Validate a project-specific contract or expected JSON keys. A mismatched schema means port collision, not an application API failure.

## Execution safety

For trading/automation consoles:

- Dashboard endpoints are GET-only.
- Render execution state prominently.
- Never infer authorization from a healthy dashboard, current data, passing tests, or operator visibility.
- Avoid mutation buttons until each action has a separately reviewed fail-closed backend boundary.
- Show unknown data as unknown/blocked, not healthy.

## Verification language

Keep evidence categories explicit:

- **Browser inspection:** page rendered, navigation worked, no obvious clipping.
- **Ad-hoc verification:** a focused temporary probe exercised changed behavior.
- **Canonical suite green:** only when the repository's recognized test/build command passed after the final edits.

Do not call browser inspection or a focused API curl “suite green.” If a workspace verifier requests an OS-safe temporary probe, create it with `tempfile` and a `hermes-verify-` prefix, execute it against the final changed behavior, and clean it up. For creative UI work, wait for visual approval before lint/test unless preparing to commit.

## One-click Windows launcher

A launcher should:

- `cd /d "%~dp0"`
- clear `PYTHONHOME` and `PYTHONPATH`
- invoke the repository virtual environment explicitly
- open the documented dashboard URL
- report that an already-running server may own the port instead of silently failing

Do not claim the launcher is verified merely because the server was started directly with Python; exercise the launcher or label it unverified.
