/* data-binder.js — Fetches dashboard_data.json and populates all widgets.
   Self-contained, no framework dependencies. Customize render functions below. */
(function () {
  "use strict";

  var DATA_URL = "dashboard_data.json";
  var REFRESH_MS = 30000;

  // ── Formatting helpers ──
  var fmt$ = function (n) {
    return n != null
      ? "$" + Number(n).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })
      : "—";
  };
  var fmtNum = function (n, d) { return n != null ? Number(n).toFixed(d || 4) : "—"; };
  var fmtPct = function (n) { return n != null ? n.toFixed(2) + "%" : "—"; };

  function colorTrend(v) {
    if (v == null || v === 0) return "";
    return v > 0 ? "trend-pos" : "trend-neg";
  }

  // ── DOM helpers ──
  // Find a tbody by the heading text of its parent panel
  function findTbodyAfter(text) {
    var hdrs = document.querySelectorAll(".panel-title");
    for (var i = 0; i < hdrs.length; i++) {
      if (hdrs[i].textContent.trim().startsWith(text)) {
        var panel = hdrs[i].closest(".panel");
        return panel ? panel.querySelector("tbody") : null;
      }
    }
    return null;
  }

  function findListAfter(text) {
    var hdrs = document.querySelectorAll(".panel-title");
    for (var i = 0; i < hdrs.length; i++) {
      if (hdrs[i].textContent.trim().startsWith(text)) {
        var panel = hdrs[i].closest(".panel");
        if (!panel) return null;
        return panel.querySelector(".data-list") || panel.querySelector(".log-list") || panel.querySelector(".panel-body");
      }
    }
    return null;
  }

  // ── Renderers (customize these for your panels) ──
  function renderFactorLeaders(data) {
    var tbody = findTbodyAfter("Factor");
    if (!tbody || !data.leaders || !data.leaders.length) return;
    tbody.innerHTML = data.leaders.map(function (r, i) {
      return "<tr>" +
        "<td>" + (i + 1) + "</td>" +
        "<td class='ticker'>" + r.ticker + "</td>" +
        "<td class='" + colorTrend(r.entropy) + "'>" + fmtNum(r.entropy, 3) + "</td>" +
        "<td class='score'>" + fmtNum(r.score, 4) + "</td>" +
        "</tr>";
    }).join("");
  }

  function renderHeader(data) {
    var ts = document.getElementById("header-timestamp");
    if (ts) ts.textContent = "Last Update: " + (data.last_update || "—");
    var badge = document.getElementById("market-badge");
    if (badge) {
      var mkt = data.market_status || "—";
      badge.textContent = "● " + mkt;
      badge.className = "badge " + (mkt === "OPEN" ? "badge-green" : "badge-grey");
    }
  }

  function renderPortfolio(data) {
    var p = data.portfolio;
    var ids = { equity: "val-equity", cash: "val-cash", buying_power: "val-buying-power", positions_count: "val-positions" };
    Object.keys(ids).forEach(function (k) {
      var el = document.getElementById(ids[k]);
      if (el) el.textContent = k === "positions_count" ? String(p[k] || "—") : fmt$(p[k]);
    });
  }

  // ── Main ──
  function loadData() {
    fetch(DATA_URL + "?_=" + Date.now())
      .then(function (r) { if (!r.ok) throw new Error("HTTP " + r.status); return r.json(); })
      .then(function (data) {
        renderHeader(data);
        renderFactorLeaders(data.factor_leaders || {});
        renderPortfolio(data);
        // Add more render calls here
      })
      .catch(function (err) { console.warn("Dashboard fetch failed:", err.message); });
  }

  loadData();
  setInterval(loadData, REFRESH_MS);
})();