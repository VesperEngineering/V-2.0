---
name: live-file-dashboard
title: Live Dashboard from File-Based Data
versions: 1.0.0
description: |
  Build a live-updating dashboard backed by file-based data sources (JSON, markdown)
  with three components: Python aggregator, single-page HTML/CSS, and JS data binder.
  Pattern proven on the Vesper Factor Dashboard.
triggers:
  - building a monitoring dashboard from file-based data
  - creating a live single-page status/ops panel
  - wiring HTML tables to JSON files that update periodically
  - user asks for "live dashboard" or "operations panel" backed by files
  - any "Phase 2" wiring of a static HTML mockup to real data
pitfalls:
  - "Patching DOM IDs in existing HTML with patch tool: old_string must include surrounding context (the metric-label text) to ensure uniqueness. Plain span or td matches will hit wrong occurrences."
  - "Metric card ID updates are especially fragile -- verify all IDs at once with getElementById checks in browser_console after each patch batch."
  - "HTTP server (python -m http.server) dies between sessions. Restart before testing."
  - "Browser tool viewport is around 640px tall. Dashboard built for 1080p will scroll. Always run document.querySelector('.main').scrollTop = 999 before checking bottom panels."
  - "Factor scores JSON schema changes between runs -- validate details field exists before accessing nested fields."
---

# Live File-Based Dashboard

Reference files: `references/aggregator-skeleton.py` (canonical Python aggregator), `references/data-binder-skeleton.js` (canonical JS binder), `references/dark-theme.css` (CSS design system).

## Architecture

```
CRON (every 30m)
  │
  ▼
aggregator.py ── reads ──► data/files/*.json, artifacts/*.md
  │
  ▼
dashboard_data.json ──── served by HTTP server
  │
  ▼
index.html ── fetches ──► dashboard_data.json (every 30s)
  │
  ▼
data-binder.js ── populates ──► DOM tables, cards, lists
```

Three files that work together:
1. **`aggregator.py`** — runs periodically, reads latest data files, outputs unified JSON
2. **`index.html`** — single-page dashboard with CSS design system and static structure
3. **`data-binder.js`** — fetches JSON and populates all DOM elements, auto-refreshes

## 1. Aggregator Design

The aggregator is a Python script that:
- Finds the latest file matching a glob pattern in a data directory
- Parses structured data (JSON) and semi-structured data (markdown tables via regex)
- Exports a single `dashboard_data.json` with all panels pre-computed

Key patterns:
- `_latest_json(glob)` — sort by st_mtime, return most recent
- `_latest_md(dir, glob)` — same for markdown files
- `_latest_md_skip_validation(dir, glob)` — skip files with `_validation` in name
- Each panel is a top-level key in the output dict
- Write output to BOTH the project directory AND the HTTP serving directory
- Include `generated_at` and `last_update` timestamps in the output

## 2. HTML Design System

Use CSS custom properties for the entire design system in one block:
```css
:root {
  --bg-primary: #0a0a0a;
  --bg-card: #111111;
  --border-primary: #1f1f1f;
  --text-primary: #ffffff;
  --text-muted: #888888;
  --accent-green: #22c55e;
  --accent-blue: #3b82f6;
  --sidebar-width: 220px;
  --header-height: 48px;
  --footer-height: 44px;
}
```

Layout: CSS Grid with fixed sidebar, fixed header/footer, scrollable main area.
Cards: 8px border-radius, 1px `#1f1f1f` borders, `#111` background.
Tables: 10px uppercase headers in `#666`, 11px tabular-nums body, alternating rows.
Status indicators: 6px colored dots (green for running, grey for idle).

Do NOT add `id` attributes to every element during initial build — only add them when wiring
data bindings. Use a separate JS file (`data-binder.js`) loaded via `<script>` tag.

## 3. Data Binder JS

Self-executing anonymous function pattern:
```javascript
(function() {
  "use strict";
  var DATA_URL = "dashboard_data.json";
  var REFRESH_MS = 30000;

  function loadData() {
    fetch(DATA_URL + "?_=" + Date.now())
      .then(r => r.json())
      .then(data => { /* populate DOM */ })
      .catch(err => console.warn(err));
  }

  loadData();
  setInterval(loadData, REFRESH_MS);
})();
```

DOM targeting: prefer structural selectors over IDs where possible.
Use `findTbodyAfter("Panel Name")` pattern — walk `.panel-title` elements,
find their parent `.panel`, then query `tbody` inside.
This avoids needing IDs on every table body.

Render functions for each panel:
- `renderFactorLeaders(data)` — builds `tr` strings, sets `innerHTML` on tbody
- `renderActiveJobs(data)` — status dots: green for running, grey for idle
- `renderSelectedBasket(data)` — weight bars with proportional width
- `renderTodaysData(data)` — simple key-value list
- `renderRecentActivity(data)` — log entries with optional `highlight` class
- `renderPortfolio(data)` — target by `getElementById` for metric cards
- `renderHeader(data)` — timestamp and market badge

Color-coding helpers:
- `colorTrend(v)`: `v > 0 ? "trend-pos" : "trend-neg"` (returns empty for zero)
- `fmt$(n)`: locale-aware dollar formatting
- `fmtPct(n)`: two-decimal percentage

## 4. Unified One-Page Operator Variant

When the user wants a darker, unified console rather than separate views:

- Use a near-black canvas (`#020304`), restrained panels (`#080a0d`), and low-contrast borders (`#181c24`). Reserve green/red for operator state.
- Render every major section continuously; do not toggle sections with `display:none`.
- Replace the permanent sidebar with compact fixed top navigation. Buttons should use `scrollIntoView({behavior: "smooth", block: "start"})` and update active state without hiding sections.
- Pair fixed navigation with a sticky telemetry row. Set `scroll-padding-top` and `scroll-margin-top` so headings remain visible.
- Bound table and log heights with internal scrolling so one feed cannot dominate the page. Logs and Settings may retain pop-outs.
- If the preferred port is occupied by another dashboard, choose an adjacent port rather than disrupting the existing service.

For creative UI changes, visually inspect first and wait for approval before formal verification. Once approved, run a focused ad-hoc probe that fetches HTML, JavaScript, and live JSON; assert section anchors, continuous rendering, navigation behavior, refresh interval, API schema, and fail-closed execution state. Create it under an OS-native `hermes-verify-` tempfile path, remove it afterward, and report it as ad-hoc—not canonical suite-green—evidence.

## 5. Testing and Verification

After each change batch, verify with browser_console:
```javascript
// Check all metric IDs
['val-equity','val-cash','val-buying-power','val-positions']
  .map(id => document.getElementById(id)?.textContent || 'MISSING')

// Check row counts
document.querySelectorAll('.panel-body tbody')[0].querySelectorAll('tr').length

// Scroll to bottom panels
document.querySelector('.main').scrollTop = 999
```

## 6. Cron Refresh

Set up a cron job that runs the aggregator every 30 minutes:
```
cronjob action=create name="Dashboard Data Refresh"
  schedule="every 30m" deliver="local"
  prompt="cd /path/to/project && python aggregator.py"
```

The dashboard auto-refreshes every 30s, so it picks up new JSON within
that window after the cron job fires.

## 7. Common Bugs

For dashboards that expose streaming-pipeline logs, queue health, or local-LLM status, read `references/operational-log-truth.md` before interpreting errors. It covers restart boundaries, historical-versus-active failures, backpressure throughput, Ollama thinking controls, and Windows console encoding.

- **Patch uniqueness**: When adding IDs to HTML with patch tool, always include
  surrounding context lines (use the metric-label text, parent div structure) in old_string.
  A plain `<span class="metric-value">` will match every metric value on the page.

- **Double-dollar in format**: After patching a `$123.45` value with an ID,
  the raw placeholder should show `$—` not `$$—`. The `fmt$()` function adds the dollar prefix.

- **Browser cache**: Append `?_=Date.now()` to the fetch URL to bust cache.

- **Server persistence**: `python -m http.server` must be started with
  `terminal(background=true)` and checked before every browser_navigate.

- **Aggregator root path**: If the aggregator script lives outside the project
  directory, hardcode or env-var the project root. Don't rely on `__file__`-relative
  path inference when the script is in a different drive letter.