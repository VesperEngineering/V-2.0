---
name: external-side-effect-safety
description: "Design and adversarially verify fail-closed integrations that combine remote mutations with local persistence."
version: 1.4.0
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [safety, idempotency, reconciliation, transactions, concurrency, external-api]
    related_skills: [requesting-code-review, systematic-debugging, test-driven-development]
---

# External Side-Effect Safety

Use for brokers, payments, production control APIs, smart devices, deployment systems, or any workflow where a remote mutation must agree with durable local state.

## Principles

- Fail closed at every mutation boundary, including cleanup, cancellation, liquidation, and shutdown.
- Persist a unique intent before remote mutation; treat ambiguous outcomes as unknown.
- Atomically reserve every scarce limit consumed by pending effects (cash, slots, inventory, quota) in the same transaction that creates the intent.
- Keep reservations through pending, unknown, partial, and locally-open states until authoritative remote reconciliation or verified-flat cleanup releases them; remote balance/position snapshots may lag.
- Reconcile only responses whose remote identity and idempotency key match exactly.
- Run reconciliation at startup and periodically; unresolved intents gate new mutations without disabling monitoring and recovery workers.
- Close the mutation gate before reconciliation starts and keep one shared lock across its remote snapshot, local updates, and result publication; this serializes reconciliation with submissions, compensation, verified-flat cleanup, and EOD latches. Exceptions leave the gate closed. In asyncio systems, run the entire lock-held synchronous critical section in a worker thread—never acquire a `threading.Lock` on the event-loop thread and then await.
- Validate untrusted cache/API/config data by exact type and domain grammar rather than coercing values into plausible shapes.
- Model partial effects explicitly; cancellation does not imply zero exposure.
- Require exact local row effects and non-masking resource cleanup.
- Serialize shared state transitions and supervise critical workers.
- Make additive migrations repeat-safe and concurrency-safe.
- Keep external execution disabled throughout tests and review unless the user explicitly authorizes a controlled smoke test.
- Protect singleton ingress and mutation authority with a process-lifetime OS file lock; acquire it before recovery or network startup and release it in `finally`.
- Verify exact remote account identity before every cleanup mutation, then cancel and liquidate only assets attributable to durable local ownership; account-wide cleanup is unsafe even on a nominally dedicated account.

## Workflow

1. Enumerate every remote-mutating path and its local-state transition.
2. Define invariants for identity, idempotency, uncertainty, partial effects, and compensation.
3. Write adversarial tests before fixes.
4. Implement the smallest invariant-preserving change.
5. Exercise connect/insert/commit/update/close failures and malformed remote states.
6. Run the project suite and a focused direct probe.
7. Send the exact staged diff to a fresh independent fail-closed reviewer.
8. For safety-critical changes, continue focused fix/review cycles until security and logic errors are empty; escalate only on churn, conflicting requirements, or a concrete blocker.

## Detailed Checklist

See [references/adversarial-checklist.md](references/adversarial-checklist.md) for transaction, API-state, cancellation, migration, and concurrency probes. See [references/async-reconciliation-locking.md](references/async-reconciliation-locking.md) for the non-blocking gate/lock pattern and race probes. See [references/runtime-ownership-and-scoped-cleanup.md](references/runtime-ownership-and-scoped-cleanup.md) for cross-process singleton locks, account identity gates, and strategy-owned cleanup.

## Pitfalls

- A disabled submit path does not protect an ungated cleanup path.
- HTTP success does not prove semantic acceptance.
- Timeout or malformed response may occur after acceptance.
- `404` after cancellation does not necessarily prove zero effect.
- JSON booleans are numbers in several languages; reject them explicitly where numeric quantities are required.
- A successful commit can be masked by a failing close unless cleanup is non-throwing; in journal/queue pipelines this can permanently lose downstream processing because replay sees a durable duplicate.
- Checking a latch under a lock but setting it outside the lock preserves a race.
- `IF NOT EXISTS` alone does not make discovery-plus-migration atomic.
- Serializing POST calls does not enforce risk limits: accepted-but-unfinished effects must consume capacity before the remote call.
- Checking only current remote state (positions, balance, inventory) ignores locally durable pending/unknown intents; enforce limits against both under one transaction.
- Recover an existing idempotency key before testing new capacity, or duplicate retries can be blocked instead of reconciled.
- A migrated active intent with unknown reservation size must block conservatively until reconciled; never assume its reservation is zero.
- Setting a reconciliation gate false but releasing the shared lock during the remote call still permits stale-snapshot races: verified-flat cleanup can mark an intent closed, then late reconciliation can resurrect it to pending/open after the cleanup latch is set. Serialize the complete snapshot-to-local-update interval.
- Publishing the reconciliation result only after the call is insufficient if the previous `true` gate remains visible while the call is in progress; close it before invoking the remote API and leave it closed on exceptions.
- In asyncio code, acquiring `threading.Lock` on the event-loop thread before `await asyncio.to_thread(...)` can starve pings, ingress, supervision, and shutdown for the full network timeout. Close the gate immediately, then offload one synchronous helper that acquires the lock and performs snapshot → local updates → result publication without releasing it.
