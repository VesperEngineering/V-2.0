---
name: desktop-gui
description: "Build native desktop GUIs with the toolkit matched to the workload: Tkinter/ttk for dashboards and PySide6/Qt for rich document apps, PDF output, and Windows packaging."
trigger:
  - User asks for a "dashboard", "GUI", "desktop app", "tool", or "visualisation"
  - User asks for a native document reader/editor, Markdown preview, PDF export, or packaged Windows app
  - User says "i want it boring", "not flashy", "no web dashboard", "native windows"
  - Building a monitoring panel for a quant pipeline or cron schedule
---
# desktop-gui

Build functional native desktop GUIs with the toolkit chosen by capability.
Use Tkinter + ttk for compact dashboards, monitoring controls, timers, charts, and log panes; use PySide6/Qt for rich documents, Markdown rendering, native PDF export, and application-grade packaging.
Prioritise clarity and function, then add restrained visual identity when the user wants polish.

## When to use

- User asks for a "dashboard", "GUI", "desktop app"
- User says "i want it boring", "not flashy", "no web dashboard"
- Building a monitoring/controls panel for a quant pipeline or cron schedule

## Choose the toolkit by capability

Default to Tkinter + ttk for compact dashboards, monitoring panels, tables, controls, logs, and simple charts. Do **not** force Tkinter onto document-centric applications when that would mean rebuilding standard document behavior.

Use PySide6/Qt when the app needs rich-text or Markdown rendering, source/preview panes, native PDF printing, robust drag-and-drop, document actions, recent files, or persistent window state. Qt's `QTextDocument`, `QTextBrowser`, `QPrinter`, `QAction`, and `QSettings` provide these directly and keep the implementation smaller and more reliable than a custom Tkinter renderer. See `references/pyside6-markdown-editor.md` for the proven architecture and verification matrix.

For a public Windows release, do not stop at a successful source build. Produce a branded portable directory, launch-test the packaged EXE, validate the ZIP and checksum, publish both assets, then download them back from GitHub and verify the public checksum. See `references/windows-release-publishing.md` for the complete release checklist and GitHub Actions version-alias pitfall.

## Dark theme

Use `ttk.Style` with `theme_use("clam")`. Set background `#1e1e1e`, foreground `#d4d4d4`, selection `#264f78`.

**Critical**: ttk widgets use **string** values for `relief`/`anchor`/`justify` (e.g. `"sunken"`, `"w"`), NOT tkinter constants (`tk.SUNKEN`, `tk.W`). Mixing them causes `TclError: expected integer but got "UI"`. `Menu` widgets do **not** support `selectbackground` — only `bg` and `fg` work.

## Canvas bar chart (no clipping)

Always use `winfo_width()`/`winfo_height()` for actual dimensions (returns \\`1\\` if unmapped — provide fallback). Calculate padding:
- `pad_l, pad_r = 24px` — first/last ticker labels
- `pad_t = 22px` — value text above tallest bar
- `pad_b = 24px` — ticker labels below bars

Draw width = `max(cw - pad_l - pad_r, 100)`, draw height = `max(ch - pad_t - pad_b, 40)`.
Bar width = `max((draw_w - gap * (n + 1)) // n, 24)`.
First bar x0 = `pad_l + gap`, last bar ends at `pad_l + gap + n*(bw+gap)`. This guarantees no clipping at either edge.

Floor minimum drawing area to avoid divide-by-zero on narrow canvases.

## Real-time timer / countdown

Use `master.after(ms, callback)`.

### Format showing seconds (HH:MM:SS)

Always show seconds — the user will notice a static countdown that doesn't tick:

```python
def _fmt(td: timedelta) -> str:
    s = int(td.total_seconds())
    neg = "-" if s < 0 else ""
    s = abs(s)
    h, r = divmod(s, 3600)
    m, s = divmod(r, 60)
    return f"{neg}{h:02d}:{m:02d}:{s:02d}"
```

### Fast tick + slow refresh (split pattern)

**Never put file I/O inside the live countdown tick.** File reads (globbing for latest scores, baskets, news files, reading timestamps) are orders of magnitude slower than arithmetic, and a single slow glob causes a visible UI hitch once per tick.

Split into two independent after-loops:

```python
def _tick(self):
    """1-second tick — live countdown + progress bar. No file I/O."""
    now = datetime.now(timezone.utc)
    events = [(self._next_run(j["hour"], j["minute"]), j["name"]) for j in SCHEDULE]
    nxt_dt, nm = min(events, key=lambda x: x[0])
    self._countdown_var.set(f"→ {nm} in {_fmt(nxt_dt - now)}")
    # progress bar across 24h window
    elapsed = (now - (nxt_dt - timedelta(days=1))).total_seconds()
    total = (nxt_dt - (nxt_dt - timedelta(days=1))).total_seconds() or 1
    pct = min(max(int(elapsed / total * 100), 0), 100)
    self._progress["value"] = pct
    self._pct_var.set(f"{pct}%")
    self.master.after(1000, self._tick)

def _refresh_schedule(self):
    """30-second tick — file reads, status dot. Runs independently."""
    for job in SCHEDULE:
        p = self._last_file_for(job["name"])
        ts = _mtime(p)
        self._sched_labels[job["name"]]["next"].set(...)
        self._sched_labels[job["name"]]["last"].set(...)
    self.master.after(30_000, self._refresh_schedule)
```

Call both in `__init__`:

```python
self._tick()
self._refresh_schedule()
```

## Multiple cron job countdowns (per-job rows)

When the user has 5+ cron jobs, show each one as an individual row with its own progress bar:

```
┌─ Cron Schedule — 8 jobs ───────────────────────────────────────────┐
│ ● Factor Scores      2:00   10:31:44  ████████████████████░░░░  85%│
│ ● Factor Basket      2:30   11:01:44  ████████████████████░░░   87%│
│ ● Alpaca Rebalance  14:30   23:01:44  ████████░░░░░░░░░░░░░░░░  41%│
│ ● Portfolio Snap     20:00   04:31:44  ██████░░░░░░░░░░░░░░░░░░  30%│
└───────────────────────────────────────────────────────────────────┘
```

Build rows lazily on the first `_tick` call. Each row stores its widgets in a tuple for fast updates (no file I/O in the 1s tick loop):

```python
SCHEDULE = [
    {"name":"Factor Scores",    "hour":2,  "minute":0,  "days":"daily"},
    {"name":"Factor Basket",    "hour":2,  "minute":30, "days":"daily"},
    {"name":"Alpaca Rebalance", "hour":14, "minute":30, "days":"mon-fri"},
    {"name":"Portfolio Snap",   "hour":20, "minute":0,  "days":"mon-fri"},
]

def _tick(self):
    n = datetime.now(timezone.utc)
    if not self._sjobs:
        for j in SCHEDULE:
            row = ttk.Frame(self._sf); row.pack(fill=tk.X, pady=0)
            dot = tk.Canvas(row, width=10, height=10, highlightthickness=0, bg=BG)
            dot.pack(side=tk.LEFT, padx=(3,0))
            d = dot.create_oval(1,1,9,9, fill=RED, outline="")
            nl = StringVar(value=j["name"])
            nx_l = StringVar(value="—"); cd_l = StringVar(value="—")
            pr = ttk.Progressbar(row, mode="determinate")
            last_l = StringVar(value="—")
            # ... pack all widgets ...
            self._sjobs.append((j["name"], j, dot, d, nl, nx_l, cd_l, pr, last_l))
    # Update each row (arithmetic only — no file I/O)
    for nm, j, dot, d, nl, nx_l, cd_l, pr, last_l in self._sjobs:
        dow = n.weekday(); days = j.get("days", "daily")
        if days == "mon" and dow != 0: active = False
        elif days == "mon-fri" and dow >= 5: active = False
        else: active = True
        nx = n.replace(hour=j["hour"], minute=j["minute"], second=0, microsecond=0)
        if nx <= n or not active: nx += timedelta(days=1)
            # Fast-forward past invalid days
            while True:
                d2 = j.get("days", "daily"); dow2 = nx.weekday()
                if d2 == "mon" and dow2 == 0: break
                if d2 == "mon-fri" and dow2 < 5: break
                if d2 == "daily": break
                nx += timedelta(days=1)
        nx_l.set(nx.strftime("%H:%M"))
        cd_l.set(_fmt(nx - n))
        prev = nx - timedelta(days=1)
        tot = (nx - prev).total_seconds()
        el = (n - prev).total_seconds()
        pr["value"] = min(max(el / tot * 100, 0), 100) if tot else 0
        # Status dot (do file I/O in a 30s separate loop, or inline here)
        dot.itemconfig(d, fill=GREEN if active else "#555")
    self.m.after(1000, self._tick)
```

Key design decisions:
- `"days"` key supports: `"daily"`, `"mon"`, `"mon-fri"` — auto-skips on weekends
- Status dots: green (active), grey (weekend skip)
- No file I/O in the 1s tick — status reads go in a separate 30s loop

**Don't cram all schedule info into one row of long strings.** That clips, feels cramped, and makes the next-run time hard to spot.

Use a three-layer layout inside the LabelFrame:

```
┌─ Schedule ────────────────────────────────────────┐
│ [🟢] → Factor Scores in 1h 23m 17s               │  ← bold green countdown
│ █████████████████████████████████░░░░░  87%       │  ← full-width progress + %
│ Factor Scores    │ Factor Basket      │ News       │  ← 3 equal columns
│  next 02:00 UTC  │  next 02:30 UTC    │  next ...  │
│  last 05:42 UTC  │  last 00:41 UTC    │  last —    │  ← dimmed
└───────────────────────────────────────────────────┘
```

Implementation:

```python
# Row 0: big countdown
row0 = ttk.Frame(cron_frame); row0.pack(fill=tk.X, padx=8, pady=(4,0))
self.dot = tk.Canvas(row0, width=14, height=14, highlightthickness=0, bg=BG)
self.dot.pack(side=tk.LEFT, padx=(0,6))
self.dot.create_oval(1,1,13,13, fill=RED, outline="")
self._countdown_var = StringVar(value="—")
ttk.Label(row0, textvariable=self._countdown_var,
          font=("Segoe UI", 13, "bold"), foreground=GREEN).pack(side=tk.LEFT)

# Row 1: full-width progress bar
row1 = ttk.Frame(cron_frame); row1.pack(fill=tk.X, padx=8, pady=(2,3))
self._progress = ttk.Progressbar(row1, mode="determinate")
self._progress.pack(fill=tk.X, side=tk.LEFT, expand=True)
self._pct_var = StringVar(value="")
ttk.Label(row1, textvariable=self._pct_var, font=("Segoe UI", 8),
          width=5, anchor="e").pack(side=tk.LEFT, padx=(6,0))

# Row 2: 3-column schedule cards
info = ttk.Frame(cron_frame); info.pack(fill=tk.X, padx=8, pady=(0,4))
for i, job in enumerate(SCHEDULE):
    col = ttk.Frame(info)
    col.grid(row=0, column=i, padx=6, sticky="nsew")
    info.columnconfigure(i, weight=1, uniform="cron_col")
    ttk.Label(col, text=job["name"], font=("Segoe UI", 9, "bold")).pack(anchor="w")
    self._sched_labels[job["name"]] = {
        "next": StringVar(value="next —"),
        "last": StringVar(value="last —"),
    }
    ttk.Label(col, textvariable=self._sched_labels[job["name"]]["next"],
              font=("Segoe UI", 8)).pack(anchor="w")
    ttk.Label(col, textvariable=self._sched_labels[job["name"]]["last"],
              font=("Segoe UI", 8), foreground="#888").pack(anchor="w")
    if i < len(SCHEDULE) - 1:
        ttk.Separator(info, orient=tk.VERTICAL).grid(row=0, column=i, rowspan=3,
                                                     sticky="ns", padx=2)
```

## Notebook tabs (dark theme)

When using `ttk.Notebook` with a dark background, default tab styling is invisible. Add this to `_apply_dark()`:

```python
s.configure("TNotebook", background=BG)
s.configure("TNotebook.Tab", background=HEADER, foreground=FG, padding=[12, 4], font=("Segoe UI", 10))
s.map("TNotebook.Tab", background=[("selected", SELECT), ("active", "#3a3a3a")],
      foreground=[("selected", FG), ("active", FG)])
```

Without this, tab labels blend into the background and become unreadable.

## Auto-refresh

Increment a counter inside the timer callback. Every 300 ticks (5 minutes at 1s), call `self.refresh()` to pick up new data from cron.

```python
self._auto_refresh_count += 1
if self._auto_refresh_count >= 300:
    self._auto_refresh_count = 0
    self.refresh()
```

## Loading all ranked tickers

When loading scores from JSON, prefer the `"scored"` key (all entries) over `"top_10"`:
```python
all_items = data.get("scored") or data.get("top_10", [])
```
This shows every ticker that was scored, not just the top slice.

## File modification time helpers

```python
def _mtime(path: Path | None) -> str | None:
    """Return full timestamp: '2026-07-06 06:45 UTC'."""
    if not path or not path.exists(): return None
    ts = datetime.fromtimestamp(path.stat().st_mtime, tz=timezone.utc)
    return ts.strftime("%Y-%m-%d %H:%M UTC")

def _mtime_date(path: Path | None) -> str | None:
    """Return date portion only: '20260706' (exact match for feed filter)."""
    if not path or not path.exists(): return None
    ts = datetime.fromtimestamp(path.stat().st_mtime, tz=timezone.utc)
    return ts.strftime("%Y%m%d")
```

Use `_mtime()` for display, `_mtime_date()` for equality comparison in the data feed. The substring check `today in ts` is fragile because `"20260706"` is not a substring of `"2026-07-06 06:45 UTC"`.

## Subprocess management

`cwd` must be the project root, not the script directory. For scripts in `scripts/`, use `Path(__file__).resolve().parent.parent`.

Auto-refresh on success inside the `_run` helper. Log stdout last 3 lines and stderr last 5 lines on failure.

Disable all toolbar buttons while subprocess runs to prevent double-clicks. Track buttons in `self._buttons` and call `_set_buttons(False)` before, `_set_buttons(True)` after (including in finally/except paths).

## Center-aligning numeric Treeview columns

Numeric columns (score, weight, rank, etc.) should be center-aligned. Ticker columns stay left-aligned:

```python
for c in ("score", "entropy", "hurst", "rvol", "sent", "insider"):
    self.st.column(c, width=70, anchor="center")
self.st.column("ticker", width=65)  # left-aligned by default
```

Apply to ALL trees consistently: scores, basket, performance, history.

## Portfolio bar with Alpaca data

Add an Alpaca portfolio bar between the schedule and the notebook tabs. Show equity, cash, position count, and buying power from the latest receipt JSON:

```python
pf = ttk.LabelFrame(master, text="Portfolio")
pf.pack(fill=tk.X, padx=5)
r = ttk.Frame(pf); r.pack(fill=tk.X, padx=5, pady=2)
ttk.Label(r, textvariable=self._equity, font=("Segoe UI", 9, "bold")).pack(side=tk.LEFT, padx=10)
ttk.Label(r, textvariable=self._positions, font=("Segoe UI", 9)).pack(side=tk.LEFT, padx=10)
ttk.Label(r, text="Alpaca Paper", font=("Segoe UI", 8), foreground="#888").pack(side=tk.RIGHT, padx=10)
```

Load from `_last_receipt()` (glob for `alpaca_receipt_*.json`):

```python
def _load_ap(self):
    rp = _last_receipt()
    if not rp: self.aeq.set("Alpaca: —"); return
    d = json.loads(rp.read_text(encoding="utf-8"))
    self.aeq.set(f"Alpaca: ${d.get('account_equity',0):,.2f}")
    self.apos.set(f"{len(d.get('target_tickers',[]))} positions")
```

## Adding a new column to an existing Treeview

1. Add the column name to the `columns` tuple in `ttk.Treeview(...)` constructor
2. Add `self.tree.heading("newcol", text="NewCol")`
3. Update the `column(width=..., anchor=...)` loop to include the new column
4. Add the value to every `insert(...)` values tuple — missing any one column shifts all subsequent data
5. Update the `_load_scores` (or equivalent) insert tuple to include the new value

## Alpaca button in toolbar

Add a "4. Alpaca" button that runs `scripts/alpaca_rebalance.py`:

```python
def _btn(text, cmd):
    b = ttk.Button(toolbar, text=text, command=cmd)
    b.pack(side=tk.LEFT, padx=2)
    self._buttons.append(b)

_btn("4. Alpaca", self.rebalance_alpaca)
```

## Alpaca notional rounding

Alpaca's REST API requires notional values to have at most 2 decimal places. `round(val, 2)` all notional amounts before submitting market orders. Skip adjustments under $1.00 to avoid noise.

## Data consistency

When user can load historical data (date-jump), all actions must operate on the **loaded** data, not the latest-on-disk:
- Maintain `self._score_data` and `self._score_map`
- In `rerank`, use `self._score_data["date"]` not `_last_scores().stem`
- After re-rank, reload scores from the same file

## Layout

- `ttk.PanedWindow` for resizable panes
- `ttk.LabelFrame` for sections with titles
- `ttk.Notebook` for tabs (Portfolio, Performance, History)
- Progress bar: `fill=tk.X, expand=True` not fixed `length`
- Alternating treeview rows via `tag_configure("odd", ...)`
- Export current tab as TSV to clipboard
- Tip bar showing keyboard shortcuts at bottom of toggle row

## Keyboard shortcuts

Bind on `self.master` so they work from any panel:
- `Ctrl+R` / `Ctrl+R` → refresh
- `Ctrl+1/2/3` → scores / rerank / basket
- `Ctrl+A` → select-all in log

## Close handler

Bind `WM_DELETE_WINDOW` via `master.protocol()` to save state before closing. Always call `master.destroy()` at the end.

## Log rotation

Cap the file log at 1 MB. On each write, check size and rotate to `.log.1`. Simple atomic rename.

## Log pane

`tk.Text` with Ctrl+A / right-click "Select All", Copy button, Clear Log button. Timestamps, `wrap=WORD`, Consolas 9, dark background.

## Pitfalls

- **Lost session work**: `patch` and `write_file` edits to GUI files only exist in the working tree. If the conversation shifts to a different topic, gets compacted, or a handoff occurs, uncommitted patches vanish with no trace. **Commit after every coherent set of changes** (`git add <file> && git commit -m "descriptive message"`) even for intermediate steps — a commit per logical chunk is fine. Do not rely on "I'll commit later" when there's an unbounded number of turns ahead or a pending topic switch.
- ttk widgets use **string** values for relief/anchor/justify, not tkinter constants
- **Font specification**: Always use a **tuple** for fonts with spaces in the name: `("Segoe UI", 10)` not `"Segoe UI 10"`. The string form causes `TclError: expected integer but got "UI"` because Tk parses the space as a field separator and tries to parse `UI` as an integer.
- `tk.Menu` does **not** support `selectbackground` — only `bg` and `fg`
- `Canvas.winfo_width()` returns `1` if unmapped — always provide a fallback
- Subprocess `cwd` must be project root, not script's directory
- `rerank` must use loaded date from `_score_data`, not `_last_scores()`
- Adding a column to Treeview requires updating heading def, column widths, AND every `insert()` value tuple — missing any one causes a silent data shift
- `Ctrl+A` on log must be bound on **both** the log widget and `self.master` to work from any panel
- Schedule text clips at right edge if using default font size 10 and wide padding — use Segoe UI 8 and column weights
- Patch tool (`patch`) can introduce indentation errors when replacing multi-line code blocks — prefer `write_file` for large GUI file replacements
- **Bulk GUI edits**: When making multiple changes to a compact dashboard file, use Python inline string replacement (`text = text.replace(old, new)`) or `sed` instead of the `patch` tool. The `patch` tool fails on compact one-liner code because it cannot reliably match multi-line `old_string` patterns against the compact format. The Python approach applies all changes in memory at once, then writes the result: `with open(...) as f: text = f.read(); text = text.replace(...); with open(...) as f: f.write(text)`
- **`.env` key loading**: use `python-dotenv` to load `.env`, store API keys for broker connections (Alpaca, FMP, etc.). round() notional amounts to 2 decimal places for Alpaca's order API

## TSV export pattern

```python
def _export_tsv(self):
    tab = self.notebook.select()
    idx = self.notebook.index(tab)
    trees = [self.scores_tree, self.perf_tree, self.hist_tree]
    if idx < len(trees):
        t = trees[idx]
        lines = ["\t".join(t.heading(c, "text") for c in t["columns"])]
        for row in t.get_children():
            lines.append("\t".join(str(v) for v in t.item(row)["values"]))
        self.master.clipboard_clear()
        self.master.clipboard_append("\n".join(lines))
```

## Monitor View layout (1920×1080)

For full-HD displays, structure the main content as a two-column split with a bottom strip:

```
┌───────────────────────────────┬──────────────────────────────┐
│ Factor Scores (20 rows)       │ Alpaca Portfolio             │
│ Ticker Score Ent  Hurst Vol   │  Equity, Cash, Positions     │
│ ...                           │  ┌─Equity Curve─────────────┐│
│                               │  │  ▁▄▇▆▅▄▃                ││
│ ┌─Bar Chart (110px)─────────┐ │  └──────────────────────────┘│
│ │ ██ AAPL ██ AVGO ██ NVDA  │ │  Today's Data               │
│ └───────────────────────────┘ │  Time  Source      Result    │
└───────────────────────────────┴──────────────────────────────┘
┌─ Nova Basket ───┬─ Factor Basket ──┬─ Log (compact) ────────┐
│ # Ticker Weight │ # Ticker  Score  │ Select All Copy Clear  │
└─────────────────┴──────────────────┴────────────────────────┘
```

Implementation:

```python
# Main area: PanedWindow with left (scores) weight=2, right (portfolio) weight=1
main_pw = ttk.PanedWindow(master, orient=tk.HORIZONTAL)
main_pw.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

left_f = ttk.Frame(main_pw); main_pw.add(left_f, weight=2)
right_f = ttk.Frame(main_pw); main_pw.add(right_f, weight=1)

# Bottom strip: 3 panels side by side in a Frame
bottom_f = ttk.Frame(master)
bottom_f.pack(fill=tk.X, padx=5, pady=(0, 5))
# Use side=tk.LEFT, fill=tk.X, expand=True for each
nova_f = ttk.LabelFrame(bottom_f, text="Nova Basket")
nova_f.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 2))
fac_f = ttk.LabelFrame(bottom_f, text="Factor Basket")
fac_f.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=2)
log_f = ttk.LabelFrame(bottom_f, text="Log")
log_f.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(2, 0))
```

- `weight=2` for scores (wider), `weight=1` for portfolio (narrower)
- Bottom strip uses `side=tk.LEFT` with `expand=True` for equal-width panels
- `height=20` for scores tree, `height=4` for basket trees
- Equity curve canvas `height=120`, bar chart canvas `height=110`

## Today's Data ingestion feed

A timeline view showing what data was ingested today, sorted by most recent:

```python
feed_f = ttk.LabelFrame(right_f, text="Today's Data")
feed_f.pack(fill=tk.BOTH, expand=True)

self.feed_tree = ttk.Treeview(feed_f, columns=("time", "source", "detail"), show="headings", height=8)
self.feed_tree.heading("time", text="Time")
self.feed_tree.heading("source", text="Source")
self.feed_tree.heading("detail", text="Result")
self.feed_tree.column("time", width=60, anchor="center")
self.feed_tree.column("source", width=130)
self.feed_tree.column("detail", width=180)
```

Build entries by checking data files on disk. Only show entries from today:

```python
def _load_feed(self):
        for r in self.feed_tree.get_children():
            self.feed_tree.delete(r)
        today = date.today().strftime("%Y%m%d")
        entries: list[tuple[str, str, str]] = []

        def _try(path, src, fmt):
            if not path or not path.exists(): return
            try:
                md = _mtime_date(path)  # YYYYMMDD, exact match
                if md == today:
                    ts = _mtime(path)
                    if ts:
                        entries.append((ts.split(" ")[1], src, fmt(path)))
            except Exception: pass

    _try(_last_scores(), "Factor Scores", lambda p: f"{json.loads(p.read_text()).get('scored_count', 0)} tickers")
    _try(_last_basket(), "Factor Basket", lambda p: f"{len(_parse_basket_md(p))} tickers re-ranked")
    _try(Path("data/insider_trades/insider_scores.json"), "Insider SEC", lambda p: f"{len(json.loads(p.read_text()).get('scores', {}))} tickers")
    _try(_last_portfolio(), "Alpaca Paper", lambda p: f"${json.loads(p.read_text()).get('account', {}).get('equity', 0):,.0f} equity")
    _try(_last_news(), "News Backfill", lambda p: f"{len(json.loads(p.read_text()).get('scores', {}))} tickers")
    trends = sorted(Path("data/google_trends").glob("*.json"))
    _try(trends[-1] if trends else None, "Google Trends", lambda p: f"{len(json.loads(p.read_text()).get('scores', {}))} tickers")
    receipts = sorted(Path("artifacts/evals").glob("alpaca_receipt_*.json"))
    _try(receipts[-1] if receipts else None, "Alpaca Rebal", lambda p: f"{len(json.loads(p.read_text()).get('target_tickers', []))} orders")

    entries.sort(key=lambda x: x[0] or "", reverse=True)
    for i, (ts, src, detail) in enumerate(entries):
        self.feed_tree.insert("", tk.END, tags=("odd" if i % 2 else "even",), values=(ts, src, detail))
    if not entries:
        self.feed_tree.insert("", tk.END, values=("—", "Waiting for data", "Snapshots accumulate over time"))
```

**Feed date window**: Instead of `today in ts` (which breaks because `"20260706"` is not a substring of `"2026-07-06"`), use `_mtime_date()` which returns `"YYYYMMDD"`. Also, show runs from the last **3 days** instead of just today — otherwise the feed is empty after a weekend:

```python
td = date.today()
if md and abs(date.fromisoformat(datetime.strptime(md, "%Y%m%d").isoformat()[:10]) - td).days <= 3:
```

## Live activity feed (_lactiv)

When the user clicks a button (scores, rebalance, basket), post an immediate entry to the Today's Data feed so they see activity NOW, not just on the next refresh:

```python
def _lactiv(self, source: str, msg: str, ok: bool = True):
    ts = datetime.now().strftime("%H:%M:%S")
    icon = "\u2713" if ok else "\u2717"
    self.feed_tree.insert("", 0, tags=("odd",), values=(ts, f"{icon} {source}", msg))
    while len(self.feed_tree.get_children()) > 50:
        self.feed_tree.delete(self.feed_tree.get_children()[-1])
```

Call from `_run` on start and completion:
```python
def _run(self, cmd, desc):
    self._lactiv(desc, "starting…", ok=False)
    # ... subprocess ...
    if success:
        self._lactiv(desc, "completed", ok=True)
```

## Factor Basket matches bar chart

The Factor Basket panel should display the top 5 tickers from `self.smap` (the factor score map), not from a separate basket file. This keeps the bar chart and Factor Basket in sync:

```python
def _lfactor(self):
    for r in self.mt.get_children(): self.mt.delete(r)
    if not self.smap:
        p = _last_basket()
        if p:  # fallback
            for i, t in enumerate(_parse_md(p), 1): ...
        return
    top5 = sorted(self.smap.items(), key=lambda x: -x[1])[:5]
    for i, (t, sc) in enumerate(top5, 1):
        self.mt.insert("", tk.END, ..., values=(i, t, f"{sc:.4f}"))
```

Vesper Selection should fall back to factor picks when no report file exists.

## Clear button clears both panels

```python
def _clr(self):
    self.lg.configure(state=tk.NORMAL)
    self.lg.delete("1.0", tk.END)
    self.lg.configure(state=tk.DISABLED)
    for r in self.ft.get_children():
        self.ft.delete(r)
```

## Bar chart auto-redraw on window resize

```python
self.bar.bind("<Configure>", lambda e: self._lbars())
```
## Python 3.10 compat

`from datetime import UTC` only works in Python 3.11+. Use `timezone.utc`:
```python
from datetime import date, datetime, timedelta, timezone
```

## Alpaca stale order cleanup

Before placing new orders, cancel all existing open orders to prevent duplicate stacking:

```python
try:
    from alpaca.trading.requests import GetOrdersRequest
    stale = client.get_orders(filter=GetOrdersRequest(status="open"))
    for o in stale:
        try: client.cancel_order_by_id(o.id)
        except: pass
    if stale: print(f"  Cancelled {len(stale)} stale orders")
except Exception:
    pass
```

## References

- `references/tkinter-patterns.md`
- `references/tkinter-font-tuple.md` — font specification bug: strings vs tuples
- `references/pyside6-markdown-editor.md` — document-centric Qt architecture, lifecycle, PDF export, packaging, and tests
- `references/windows-release-publishing.md` — branded portable builds, archive/checksum validation, GitHub Release publication, and public-download verification
- `references/alpaca-trading-integration.md` — Alpaca API setup, notional rounding, order cleanup