---
name: operator-dashboard-assurance
description: Audit and repair the trust plumbing behind operational dashboards before changing presentation or layout.
version: 1.2.0
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [dashboard, observability, data-lineage, scheduler, deployment, qa]
    related_skills: [dogfood, systematic-debugging, test-driven-development]
---

# Operator Dashboard Assurance

## Trigger

Use for dashboards that supervise autonomous systems, trading systems, scheduled pipelines, broker accounts, infrastructure, or other operations where stale or mislabeled data can create false confidence.

Use this skill when the user asks whether a dashboard is accurate, refreshing correctly, hiding background failures, or providing enough information to supervise automation.

## Core principle

**Plumbing before presentation.** If the user likes the layout, preserve it while validating and repairing source authority, freshness, health derivation, scheduler truth, and deployment consistency. Do not mix a visual redesign into a data-truth repair.

## Workflow

1. Identify the live process, command line, working directory, static root, API root, and launcher serving the inspected URL.
2. Enumerate **every runtime authority path**, not just the web server: login/startup launchers, tray/service wrappers, scheduled tasks, refresh scripts, generated-payload destinations, and any shadow writes. A repository can be authoritative in source control while a stale copy remains authoritative at runtime.
3. Prove exclusive listener ownership, not merely successful reachability. On Windows, combine `netstat -ano` with per-PID command line, working directory, and socket inspection (for example via `psutil.Process(pid).cmdline()`, `.cwd()`, and `.net_connections(kind="tcp")`). Two unrelated processes can appear to own the same loopback port; repeated successful identity responses from the intended server do not eliminate the competing-runtime risk.
4. Compare the live deployment with repository source. Treat shadow copies and duplicate frontends as P0 risks. Disable or redirect competing launchers; do not merely copy patched files into both trees.
5. Discover the actual scheduler authority from launch configuration and task state before deriving health. Do not assume an in-repository scheduler is production authority merely because its code or logs exist.
6. Trace each displayed value through source → transformation → payload → frontend, including fallbacks.
7. Distinguish raw candidates, approved execution artifacts, and actual holdings/state. Require artifact-internal provenance (for example source-session metadata), not only a plausible filename and row count.
8. Challenge reassurance labels such as `HEALTHY`, `Connected`, and `live`; require derived evidence and fail-closed behavior.
9. Separate browser-fetch age, payload age, artifact age, feed age, broker observation age, and persisted-snapshot age.
10. Identify the authoritative scheduler; verify expected versus actual runs, last result, missed runs, duration, retries, dependencies, and outputs. A failed prerequisite should remain visible even if downstream artifacts still exist.
11. Validate timezone and schedule semantics with deterministic tests, including DST and scheduler-specific weekday numbering.
12. Write focused failing regression tests before production fixes. Isolate browser formatting/cadence logic into a small pure module that can be exercised with Node when no browser unit-test harness exists.
13. Verify at three layers: unit tests, concurrent real API/HTTP output, and browser-visible state. Confirm the browser loaded the intended cache-busted bundle and inspect runtime timer/source state, not just the HTML response.
14. Only after plumbing is verified should visual/layout changes be considered.
15. If the worktree is broadly dirty, recover validation authority before repair: preserve staged/unstaged patches, restore only tracked deletions, verify workflow-required test paths exist, and distinguish a reduced surviving suite from the established baseline.
16. Time-box recovery. Once the trust gate is restored, continue with the system's highest-value bounded engineering or research lane rather than treating cleanup as the end product.

## Required trust contracts

- Every major value exposes or carries source and observation time.
- Dashboard health is derived, never hardcoded.
- Missing required evidence cannot resolve to green.
- The displayed execution artifact is the same artifact consumed by execution.
- Live and snapshot data are explicitly distinguished.
- The inspected URL is served from the exact code version tested.
- Scheduler liveness and job success are separate concepts.
- A successful HTTP response proves reachability only, not system health.

## Browser refresh and source arbitration

- Track payload polling, backend aggregation, and external live-data polling as separate timers. Clear **all** timer handles before restart; guard each request against overlap.
- Recompute cadence at session-boundary transitions, after tab visibility changes, and after sleep/resume. An initialization-only `isOpen` decision becomes stale.
- Never let a frequent persisted-snapshot render overwrite a newer live observation. Keep a recent-live watermark or explicit source priority, and label the visible value with source plus observation time.
- Do not let a live holdings response replace the approved target-basket table. Target, actual, and drift are separate widgets even if they contain the same ticker fields.
- Dynamic contribution tables should render the factors actually present in the payload. Fixed legacy columns full of zeroes are misinformation; label raw/research rankings explicitly when they have not passed universe, tradability, portfolio, and risk gates.

## Security and action-authority boundary

- Treat bind address, CORS, authentication, HTTP method, and exposed actions as part of dashboard correctness. A truthful dashboard is still unsafe if it listens on every interface, permits wildcard origins, or exposes account/order controls without an explicit authority design.
- Default operator-only dashboards to loopback. If remote access is required, require an intentional authentication, origin/CSRF, and network-exposure design rather than relying on obscurity.
- Never expose broker/order actions merely because the backend already has a callable function. Remove or disable the route and its GUI handler; return an explicit denial. Keep bounded local refresh/report actions separate from execution actions.
- API health must independently enforce payload age. An embedded historical `HEALTHY` value cannot remain healthy after aggregation stops; stale payload age overrides the embedded state and adds a reason.

## Shared execution contracts

Do not approximate an execution loader in dashboard code. Reuse the same parser/validator, or extract a shared pure contract, so exact date selection, trading-calendar rules, heading/provenance, age/future skew, cardinality, uniqueness, and ticker syntax cannot drift. If a shared loader needs an alternate artifact root for tests, resolve the default path at **call time** (`None` then current constant), not as a default argument bound at function definition; otherwise monkeypatching the runtime authority will silently fail.

## Scheduler correctness gates

- A successful last result is insufficient: also require a recent successful run. Use schedule-aware or task-specific staleness bounds that tolerate weekends/holidays but detect stopped automation.
- For cron jobs, reserve the exact matched `(year, month, day, hour, minute)` before execution. A short elapsed-time debounce can admit a second run in the same matching minute.
- Use an IANA timezone such as `ZoneInfo("America/New_York")` or browser `Intl.DateTimeFormat` with an explicit zone. Never encode permanent EDT/EST offsets or hand-maintain DST transition calculations.
- Live endpoint fields and frontend rendering contracts must match. A live refresh must not blank snapshot-derived P/L fields; either provide live equivalents or retain and explicitly label snapshot values.

## Blocked-state acknowledgment versus override

When an operator asks to “override blocked,” do not translate that into forced `HEALTHY` or bypassed execution admission. First separate three concepts:

1. **Acknowledge:** record who/when/why, suppress repetitive alerting for a bounded period, and render `BLOCKED — ACKNOWLEDGED`; all underlying blockers and execution gates remain active.
2. **Temporary observation mode:** permit read-only dashboard use while blocked, with an expiry and visible banner; no broker/order, promotion, scheduler, target/risk, or artifact-admission authority is granted.
3. **True override:** changes an execution or safety gate and therefore requires the project’s explicit approval lane, scope, expiry, audit receipt, and rollback path. Never infer this authority from a casual request to clear a dashboard warning.

Prefer acknowledgment when the user wants relief from alert noise. Never rewrite source evidence, task results, artifact timestamps, or health inputs to manufacture green. An acknowledgment must automatically clear when the blocker changes or the bounded expiry passes, and the unacknowledged status must remain available through the API and audit log.

## Scheduler mutation safety

When changing scheduled-task commands or wrappers, read back the task action, enabled state, next run, account/logon mode, and last result. On systems that require stored credentials or a specific unattended logon type, a successful task-definition update does **not** prove the next unattended run will execute. Preserve the old failure result until a new successful receipt exists.

## Testing discipline

Follow strict RED → GREEN cycles for provenance, health, freshness, schedule semantics, and API contracts. Do not claim completion after unit tests alone. Deployment and browser verification are mandatory for an end-to-end trust claim.

When parallel reviewers run pytest, give each process a unique `--basetemp` outside shared canonical artifacts. If a full run reports that its pytest base directory disappeared, rerun the affected test alone and inspect concurrent test processes before classifying it as an application defect; shared temporary-directory deletion can create a false failure.

Treat independent review as a new verification boundary, not a reporting appendix. Fix high-confidence findings, then rerun the affected tests and full suite. Any production patch after the last server start or browser check invalidates that runtime evidence: restart the deployed process, verify bind address and denied/allowed routes, regenerate the payload, and repeat browser/API checks before upgrading the verdict to trustworthy. If tool or time limits interrupt this closure loop, report the exact last-green test set and explicitly keep the verdict at not yet trustworthy.

## Operator readability and desktop discoverability

After data truth is established, verify presentation as an operator workflow rather than a static screenshot:

- Prefer readable type and vertical scrolling over a global “fit everything without scrolling” mode. At a normal 1280×625 viewport, summary tables should fit their panels and detailed sections should remain reachable by scrolling.
- Remove fake window chrome and controls that do not perform their labels. Browser dashboards should use browser behavior; native desktop controls require a real host integration.
- Summary panels should show only decision-relevant columns. Put full factor detail, scheduler history, and diagnostics in their dedicated views instead of shrinking every column into the overview.
- Do not display persisted P/L beside newer live P/L without explicit labels. Use a recent-live watermark so periodic snapshot rendering cannot overwrite the fresher observation; verify agreement across every repeated value.
- Replace raw technical diagnostics in the primary header with concise operator language, preserving the exact reason in details or hover text. A preview artifact aging out is a warning when order submission is disabled, not an execution blocker.
- Resolve the actual Windows Desktop through the Known Folder API (`[Environment]::GetFolderPath("Desktop")`); do not assume OneDrive Desktop is the visible desktop.
- For a browser/tray application without a standalone executable, create a standard `.lnk` on the resolved Desktop. Point it to a hidden launcher that starts one authoritative runtime and opens the loopback URL. Give the shortcut a recognizable icon and description.
- Verify the shortcut by launching it, reading back its target/arguments, checking the server identity contract, and confirming the listener PID did not duplicate.

## Reporting

Lead with one trust verdict: **trustworthy**, **degraded**, or **not yet trustworthy**. Separate verified facts, repaired behavior, and remaining unverified work. If interrupted, state precisely which tests passed and which deployment checks remain.

## References

- See `references/dirty-worktree-recovery.md` for preserving mixed rough-patch work, restoring tracked deletions without overwriting active edits, recovering the real validation baseline, and resuming productive bounded work after the trust gate.
- See `references/plumbing-audit.md` for the detailed audit checklist, regression targets, and common failure patterns.
- See `references/runtime-truth-patterns.md` for deployment-authority inventory, freshness vocabulary, timer/source arbitration, artifact provenance, deterministic browser tests, and scheduled-task readback.
- See `references/security-scheduler-closure.md` for loopback/action-authority probes, stale-health tests, shared execution-validator fixtures, once-per-minute scheduler checks, and the post-review verification closure loop.
- See `references/windows-desktop-launcher.md` for Known Folder shortcut creation, identity-aware launchers, typography closure, and live-versus-snapshot UI consistency checks.
