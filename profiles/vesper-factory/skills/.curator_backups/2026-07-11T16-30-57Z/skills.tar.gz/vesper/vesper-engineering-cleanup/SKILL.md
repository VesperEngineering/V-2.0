---
name: vesper-engineering-cleanup
description: Systematic audit and cleanup of Vesper engineering debt — dead code, hardcoded paths, SQL patterns, factor bloat, redundant cron, and post-rename Nova references.
---

# Vesper Engineering Cleanup

Ruthless, targeted cleanup of the Vesper quant codebase. Applies the same FM-style rigor ("kill what doesn't work") to engineering artifacts.

## Trigger Conditions

- User says "inspect engineering", "clean up code", "anything to improve"
- After a factor purge or refactor — verify nothing rotted
- After renames (Nova→Vesper) — sweep for stale references
- Cron/scheduler redundancy check
- Any time the repo feels bloated
- A large deletion set, sharply reduced test count, or suspiciously green surviving suite appears

## Recovery Gate Before Cleanup

When repository integrity is uncertain, recover the baseline before deleting or refactoring anything. Preserve staged and unstaged binary patches separately, restore only unexplained tracked deletions, verify workflow-required paths, and run layered validation. See `references/repository-recovery-and-baseline-restoration.md`.

## Audit Checklist (Run in Order)

### 1. Orphan Factor Files
```bash
# Factors on disk but NOT in registry.py
for f in app/factors/*.py; do
  name=$(basename $f .py)
  [ "$name" = "__init__" -o "$name" = "base" ] && continue
  grep -q "$name" app/factors/registry.py || echo "ORPHAN: $name"
done
```
Investigate every orphan. Delete only after confirming ownership, absence from registry/import/docs/runtime paths, and relevant passing tests. In a dirty or recovery-state worktree, preserve it until provenance is clear.

### 2. Zero-Weight Factors
Check `scripts/run_all_factors.py` — any factor with weight 0.0 is dead weight. Remove from registry AND delete the source file. The STATUS.md rule is "kill dilutive factors." Weight 0.0 = killed.

### 3. Dead Scripts (Evolutionary Artifacts)
Look for:
- `*_v2.py`, `*_v3.py`, `*_v4.py` — only v4 (or latest) is current
- `no_order_checkpoint*`, `post_rebuild*` — one-time rebuild artifacts
- `generate_*` scripts with no matching `run_*` or scheduler reference

Delete all. Git history preserves them.

### 4. Unreferenced Files
```bash
# Find scripts never called from scheduler or cron
for f in scripts/*.py; do
  name=$(basename $f)
  grep -rq "$name" scheduler/ --include="*.json" || echo "UNREF: $name"
done
```
Also check root-level `.py` files. `mine_signals.py` at root was 341 lines of unreferenced code.

### 5. Hardcoded Paths
Search for literal paths that break on other machines:
```bash
grep -rn "D:/vesper" app/ scheduler/ vesper-dashboard/ --include="*.py"
```
Replace with `VESPER_ROOT` env var or `Path(__file__).resolve().parent` relative resolution.

### 6. SQL Injection Patterns
```bash
grep -rn "\.format.*SELECT\|f\".*SELECT\|%s.*SELECT" app/factors/ --include="*.py"
```
Replace with parameterized queries using `?` placeholders. Extract shared helpers to `app/factors/db.py`.

### 7. Shared Code Extraction
Duplicated SQLite connection/open/fetch patterns across factors? Extract to `app/factors/db.py`. Same for rank z-score, winsorization, panel building — factor code should be signal logic only, not plumbing.

### 8. Cron Redundancy
Run `cronjob action=list` and compare against `scheduler/jobs.json`. Any job in both = duplicate execution. The Vesper Scheduler is primary — pause redundant Hermes jobs. Only keep Hermes jobs the scheduler can't do (LLM-driven research, one-shot reminders).

### 9. Nova/Vesper CLI Migration Audit
```bash
grep -rn "deploy/nova\.py\|deploy/vesper\.py\|Nova\b" app/ scripts/ scheduler/ deploy/ tests/ --include="*.py"
```
Treat the rename as an atomic compatibility migration, not a blind replacement. Inventory launchers, production command constructors, tests, fixtures, workflow commands, safety markers, docs, and historical evidence contracts. Keep the canonical compatibility entry point until the whole slice passes; otherwise defer the rename. Also check `.cmd`/`.ps1` launchers.

### 10. Scheduler Hygiene
- Add `RotatingFileHandler` for `scheduler.log` (5MB, 3 backups)
- Add per-job log retention (100 max per job) via `_cleanup_job_logs()`
- Verify `jobs.json` scripts all exist and reference correct paths
- Check the live scheduler process list; configured jobs are not evidence that the daemon is running

### 11. Windows Scheduled-Pipeline Verification

For critical unattended workflows, use one tested Python orchestrator and keep the
`.bat` file as a thin wrapper. The orchestrator must run dependency order
sequentially and stop on the first nonzero child exit.

1. Add targeted RED tests for ordering, downstream suppression, required artifact/data admission, and CLI dry-run behavior.
2. Make every script entry point return a meaningful status through `raise SystemExit(main())`; logging an error while returning 0 is a failed guard.
3. In the wrapper set `PYTHONUTF8=1` and `PYTHONIOENCODING=utf-8`, quote the exact interpreter, redirect logs, capture `%ERRORLEVEL%`, and `exit /b` with it. Windows Task Scheduler redirection may otherwise use CP1252 and crash on Unicode status text.
4. Query the task's exact action, trigger, user/logon mode, last result, and next run. `Ready` proves only configuration, not successful execution.
5. Run the real artifact-only task once and verify its Last Result, logs, and output artifacts. Do not manually invoke a broker/rebalance task merely to test scheduling.
6. Record whether the task is `Interactive only`; such a fallback does not survive logout and is not equivalent to a persistent daemon.
7. Broker-facing scheduled scripts need independent guards: paper endpoint, weekday, broker market-open clock, date/freshness, exact target shape, and exception propagation.
8. Update `docs/STATUS.md`, `README.md`, and `CHANGELOG.md` with verified behavior, unverified surfaces, safety boundaries, and next actions.

See `references/windows-scheduled-pipeline.md` for templates and the verification checklist.

### 11A. Dashboard / Operator-Console Plumbing Before Layout

When the user asks whether the GUI can be trusted, **do not redesign it first**. Preserve the current visual layout and audit the truth path underneath it:

1. Identify the exact process, command line, cwd, static root, startup launcher, refresh wrapper, and scheduled-task wrappers serving the GUI. Hash served assets against the intended repository copy; eliminate shadow runtime copies only after verified cutover.
2. Replace literal or unconditional `HEALTHY`, `Connected`, and `live` claims with fail-closed derived state and explicit reasons. HTTP reachability is not system health.
3. Keep browser-fetch age, payload age, score age, basket age, portfolio snapshot age, and broker-live age separate. Format offset-aware ISO timestamps once in `America/New_York`; never reinterpret already-local display strings.
4. Read the exact canonical basket consumed by rebalance. Keep raw score leaders, approved target, last executed target, snapshot holdings, and live holdings distinct.
5. Preserve raw factor values separately from governance-weighted deployed contributions. Zero-weight diagnostics cannot be labeled as active drivers.
6. Discover scheduler authority per job instead of assuming Hermes, Windows Task Scheduler, and an internal daemon are interchangeable. Exclude paused jobs from active state and verify Windows `Last Result`, not just `Ready`.
7. Use one refresh controller that owns and clears every timer, reevaluates market phase/visibility, and prevents overlapping requests.
8. Add RED tests for each misleading claim before backend or binding changes. After repair, verify focused tests, full pytest, API output, browser DOM/console, served hashes, live process command line, task results, and source artifacts.

See `references/dashboard-operator-plumbing.md` for the complete audit sequence, common failure patterns, and completion bar.

### 11B. Broker / Local-State Atomicity and Worker Supervision

For any Alpaca mutation or execution-worker change, audit the broker boundary as a distributed transaction—not a normal database write:

1. Guard **every** broker-mutating path (submission, EOD, cancellation, liquidation, retry, shutdown, and compensation) with the same enabled-paper/endpoint/account authority check.
2. Commit a unique deterministic intent before POST; retries must get-or-create and reconcile by client ID rather than POST again.
3. Represent timeout and malformed responses as unresolved uncertainty, because Alpaca may have accepted the request.
4. Require exact database row counts, non-masking cleanup, and authoritative post-state verification after compensating DELETE.
5. Supervise stream, risk, persistence, and queue workers together; any critical worker exit must stop ingress and broker mutation immediately.
6. Run adversarial probes for DB open/insert/commit/update/close failures, duplicate/concurrent retries, malformed broker responses, disabled/live mutation attempts, and each worker’s independent failure.
7. Keep execution disabled and continue independent review until a fail-closed verdict passes; a fixed review-cycle count is not deployment authority.

See `references/broker-local-state-safety.md` for the full failure matrix and stopping rule.

### 12. Concurrent Agent / Scan Handoff
When another Hermes or Codex session is already modifying `D:\vesper`, observe before acting:

1. Treat its session ID as an observability handle, not a process ID.
2. Inspect matching Hermes agent/error logs to determine model, current tool activity, termination reason, and whether delegated results arrived.
3. Do **not** edit the repository or run broad mutating commands while that session is active.
4. After it stops, inspect only the files it created or touched and run the narrowest relevant verification first.
5. Never equate `max_iterations_reached`, a final prose response, or a written test with completion. Confirm every imported module exists and execute the tests fresh.
6. If the working tree was already dirty, do not attribute the entire diff to the latest agent. Separate new files by timestamps and task scope.
7. Open-ended scans can consume dozens of subscription-backed model calls. Prefer bounded briefs with explicit deliverables, verification commands, and a call/iteration ceiling.

See `references/concurrent-agent-scan-verification.md` for the reusable monitoring and handoff checklist.

## Post-Cleanup Verification

```bash
# Always run full suite
python -m pytest tests/ -q --tb=short

# Verify factor imports
python -c "from app.factors.registry import get_registry; print(len(get_registry().names))"

# Verify scheduler compiles
python -c "import py_compile; py_compile.compile('scheduler/__init__.py', doraise=True)"

# Update STATUS.md date and summary
```

## Pitfalls

- **Broad-suite evidence must reflect the restored surface**: a green run after hundreds of test deletions is not a baseline. Preserve the dirty state, restore unexplained tracked deletions, run workflow-required tests, then run the broad suite and report exact pass/skip/fail counts. Separate deterministic repository failures from optional-runtime process corruption.
- **Dirty worktrees are user state**: never `git stash`, `git reset`, `git add -A`, broad-format, or revert unrelated paths to manufacture a baseline. Capture `git status --short`, define an allowlist, include untracked files explicitly (they do not appear in `git diff`), and compare against a previously recorded baseline or file-scoped `HEAD` evidence where valid.
- **Large legacy text can contain control characters**: after any documentation patch, inspect diff stats and hunk headers. If a tiny top-of-file edit changes hundreds of distant lines, restore the untouched bytes and reapply the intended insertion with a byte-preserving method.
- **Use targeted file tools for edits/searches**: prefer `patch`, `write_file`, `search_files`, and `read_file` over shell-wide `sed`, `grep`, or destructive batch replacements. Re-read the exact region after fuzzy edits; if adjacent lines are absorbed, stop incremental patching and rewrite the small file once from a complete read.
- **Deletion requires scope ownership**: use `git rm` only for tracked files explicitly owned by the cleanup and only after verifying imports, registry references, docs, and tests. Never infer that existing deleted tests belong to the current session.
- **Nova rename hits tests and command construction**: search both production and test paths, including `deploy/cli/data.py`; update only confirmed stale references.
- **Scheduled success must be end-to-end**: direct Python success, dry-run success, task status `Ready`, and a rewritten wrapper are each insufficient alone. Verify the real task action and Last Result through Task Scheduler.
- **Artifact success is not economic validity**: a score/basket pipeline result of 0 proves mechanics only. Keep symbol anomalies, stale-source risk, and point-in-time data defects explicit.

## Key User Preferences

- Aggressive culling: "kill dilutive factors" means DELETE them, not move to 0.0 weight
- FM is gold standard — engineering follows the same philosophy (if it doesn't carry weight, remove it)
- Honest reporting: pre-existing failures are pre-existing, say so
- Set-and-forget: once cleaned, it should stay clean
- Direct, concise: no fluff, just results
- GUI work order: prove and repair plumbing, provenance, freshness, scheduler authority, and deployment source before changing the layout; preserve the current dark visual design during trust-layer repairs
