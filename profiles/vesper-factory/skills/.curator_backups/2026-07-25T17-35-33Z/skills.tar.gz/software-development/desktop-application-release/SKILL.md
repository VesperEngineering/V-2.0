---
name: desktop-application-release
description: "Release native desktop applications safely: bounded async lifecycle, fail-closed evidence UI, independent review, canonical integration, and launcher proof."
version: 1.0.0
---

# Desktop Application Release Assurance

## Use when

Use for a native desktop/Tkinter application that reads background evidence, has a real operator launcher, or must be released from an isolated worktree into a dirty/shared canonical repository.

## Core rule

A passing unit test and a direct interpreter launch are not sufficient. Release requires an end-to-end proof of the real operator path plus an independent lifecycle review.

## Release flow

1. **Freeze scope first**
   - Capture worktree branch, HEAD, staged and unstaged paths.
   - Capture canonical branch/status separately.
   - Stage only the application-owned source, tests, and intentional docs; never absorb unrelated canonical dirt.

2. **Inventory every asynchronous path**
   - List all thread/task producers, timers, queues, result handlers, selection-triggered readers, action results, and close callbacks.
   - Include legacy/background detail readers, not only newly added coordination code.
   - Every worker result must either be handled or have an explicit drop transition that clears dependent in-flight state and safely schedules retry.

3. **Bound the lifecycle**
   - Enforce one in-flight operation per logical source.
   - Bound/coalesce pending results and bound every main-thread drain, including compatibility queues.
   - Do not evict terminal results whose handler clears UI in-flight flags unless the eviction performs the equivalent state transition.
   - Selection-driven fetches must serialize the active read, retain only the latest requested selection, launch it after the active terminal result is handled, and ignore late success *and error* results for an obsolete selection.
   - Close must cancel timers, invalidate/close coordinators, reject late completion, and prevent queued follow-up work.

4. **Make evidence failures visibly fail closed**
   - Retain last-good display values only under a global, explicit `STALE`/`ERROR`/`UNAVAILABLE` overlay with bounded reason/provenance.
   - Never leave capacity, count, posture, or “LIVE” appearance current-looking after a source failure.
   - Static `LIVE` is a posture label, never a changing sync timestamp used as freshness proof.

5. **Test with TDD**
   - Add a red regression test before each lifecycle repair.
   - Minimum cases: background failure overlay; close before worker completion; bounded/coalesced queue behavior; queue saturation; `A → B → C` selection coalescing; stale A success/error after C selection; persistence of selected page/task and scroll/follow state.
   - On Windows, isolate pytest temp state using `--basetemp=<worktree-local-temp>` if the shared pytest temp root is unavailable or locked.

6. **Run release gates**
   - Focused tests, full application suite, compile, lint, and `git diff --cached --check`.
   - Treat test infrastructure failures distinctly from assertion failures; retry in an isolated test temp directory before classifying a code regression.
   - Obtain an independent reviewer after each repair. A reviewer must inspect actual staged code and all async paths, not only the reported defect.

7. **Prove the real launcher**
   - Inspect the actual desktop shortcut target, arguments, and working directory.
   - Reconcile the reviewed candidate to canonical without overwriting unrelated dirt.
   - Launch through the shortcut, not just `python -m`.
   - Verify a visible titled window, normal and minimum geometry, readable appbar/navigation, explicit unavailable/stale behavior, and clean close lifecycle.

8. **Publish carefully**
   - Commit only the reviewed application slice.
   - Push only after canonical HEAD, remote HEAD, and intended commits are verified.
   - Report pre-existing unrelated canonical dirt explicitly; do not claim it was cleaned or included.

## Authority boundary checklist

For an operator desk, a UI refresh/release change must not silently add broker/order, provider spend, scheduler, risk, promotion, deployment, secret, or worker-dispatch authority. Mutation controls, if allowed at all, must remain exactly scoped, explicit, confirmed, and independently guarded.

## Pitfalls

- Reviewing only the new coordinator while an older detail-reader thread bypasses it.
- Draining a legacy queue unboundedly after a bounded coordinator drain.
- Coalescing a same-item selection but losing the latest distinct selection.
- Applying an error from a stale selection to the currently selected item.
- Treating “window exists” as proof that the Desktop shortcut launches the integrated canonical build.
- Fast-forwarding a worktree branch without first proving canonical dirty files do not overlap the release slice.
