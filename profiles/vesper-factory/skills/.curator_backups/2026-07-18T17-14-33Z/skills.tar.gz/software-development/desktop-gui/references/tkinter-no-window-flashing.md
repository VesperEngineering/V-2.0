# CREATE_NO_WINDOW: Stopping Console Flashing in pythonw.exe Tkinter Apps

## Problem

When a `pythonw.exe` Tkinter desktop app (like VOT or VWM) polls data via
subprocess calls (git, file checks, hermes kanban CLI), each `subprocess.run()`
or `subprocess.Popen()` without `creationflags` creates a new console window
on Windows. The window flashes open and closes within milliseconds, producing
a distracting flicker every poll cycle (e.g. every 2–5 seconds).

## Root Cause

`pythonw.exe` is a GUI-subsystem executable with no console. When it spawns
a console-mode subprocess (like `python.exe`, `git.exe`, `cmd.exe`), Windows
allocates a new console for the child process. That console window appears
briefly before the subprocess exits.

## Fix: Patch the Service Layer's Subprocess Runner

The cleanest fix is to monkeypatch the service layer's default subprocess
runner at app startup to pass `CREATE_NO_WINDOW` (`0x08000000`). This is
the same flag the VWM uses in its own `run_command()` function.

### Pattern

```python
def _patch_no_window_subprocess(self) -> None:
    """Patch subprocess runners to use CREATE_NO_WINDOW on Windows."""
    import sys
    if sys.platform != "win32":
        return
    import subprocess
    try:
        import app.services.operator_workspace_activity as _wsa
        def _no_window_runner(command, *, cwd, timeout):
            return subprocess.run(
                command,
                cwd=cwd,
                capture_output=True,
                text=True,
                timeout=timeout,
                check=False,
                creationflags=subprocess.CREATE_NO_WINDOW,
            )
        _wsa._default_runner = _no_window_runner
    except ImportError:
        pass
```

Call this once in `__init__` before the first `refresh()`.

### Why Patch the Runner, Not Each Call Site

The Vesper service layer (`operator_workspace_activity.py`,
`operator_codex_activity.py`, etc.) has multiple subprocess call sites.
Patching the single `_default_runner` function that all of them route
through is one change that covers every call — no need to modify the
service layer itself.

### VWM's Approach (Reference)

The Vesper Worker Monitor (`vesper_worker_monitor.py`) uses this pattern
directly in its own `run_command()`:

```python
creationflags = subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0
process = subprocess.Popen(..., creationflags=creationflags)
```

VOT applies the same flag but via monkeypatch because it reuses the
Vesper service layer's runner rather than having its own.

## Verification

After applying the fix, launch the app with `pythonw.exe` and watch for
one minute (covering multiple poll cycles). No console windows should
flash. The app's data should still refresh normally (the subprocesses
still run — they just don't create visible windows).

## Applies To

Any `pythonw.exe` Tkinter/PySide6 desktop app on Windows that spawns
subprocesses for data polling. Common in:
- VOT (Vesper Operator Terminal) — polls `load_dashboard_snapshot()`
- VWM (Vesper Worker Monitor) — polls `hermes kanban` CLI
- Any monitoring dashboard that shells out for data
