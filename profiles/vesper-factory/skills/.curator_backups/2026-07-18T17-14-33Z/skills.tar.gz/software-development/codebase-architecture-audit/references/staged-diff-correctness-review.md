# Staged-Diff Correctness Review Checklist

Use this when a large staged change crosses data, portfolio, execution, scheduler, worker-runtime, and operator surfaces.

## Index discipline

- Record `git status --short`, staged name/status, and staged stat first.
- Review the index, not an accidentally newer working-tree copy. Use `git show :path` when staged and unstaged content may differ.
- Recheck status at the end; distinguish pre-existing untracked files from review-created output.

## Contract tracing

For every new status, decision, receipt field, or state transition:

1. Find its producer.
2. Find every consumer and validator.
3. Check that accepted-state sets are shared and complete.
4. Check that negative states cannot pass through substring matching.
5. Check immutable identity fields across the chain (task/order ID, symbol, side, amount, date, artifact hash).

Typical decisive defects:

- A `PASS` receipt whose semantic decision says `no action` reaches a mutating path.
- A newly introduced success state is rejected by older downstream validators.
- Reconciliation matches “latest by symbol” instead of the exact idempotency key.
- A calendar gate checks weekday/fixed hours instead of exchange holidays and early closes.
- A historical portfolio path silently reads the latest available observations (lookahead).
- Per-asset arrays have equal lengths but represent different dates (calendar misalignment).
- Append-only ledgers perform read/check/append without a process lock or transaction.
- Terminal events are accepted without a valid predecessor transition.

## Test-integrity checks

- Inspect changed assertions and skips separately from implementation changes.
- Treat changing the input so the old invariant is no longer exercised as expectation laundering.
- Reject autouse skips based on untracked/generated local artifacts; construct deterministic fixtures under `tmp_path`.
- Exercise tests with an external writable pytest basetemp when the repository must remain read-only. On a Windows host where the shell is MSYS/Git Bash but `python` is native Windows, pass `--basetemp` as a native absolute path such as `C:/Users/<user>/AppData/Local/Temp/<unique-id>`; `/c/...` may be interpreted by `pathlib` as a path relative to the repository drive. Use a fresh UUID path, disable bytecode/cache output, and recheck repository status afterward.
- Add deterministic probes for uncovered indexing, alignment, and transition bugs; retain the actual exception/output as evidence.

## Authority and concurrency boundary reviews

When the staged slice changes a steward, coordinator, worker runtime, provider adapter, or append-only ledger:

1. **Prove reachability, not just declarations.** Search the staged index for concrete model/provider call primitives, process launchers, and every caller. A lane's model name, quota allocation, prompt, or provider field is declarative until reachable from the entrypoint.
2. **Prove removed authority is really absent.** Check both the staged file list and filesystem for retired runtime/provider modules, then scan for stale imports and alternate call paths. A disabled lane alone is insufficient if another entrypoint can invoke the runtime.
3. **Exercise the hostile packet.** In an external temporary root, pass a packet containing runtime, model, prompt, and path fields. Verify zero dispatch, zero provider receipt, and zero artifact write. This probe must not use credentials or touch repository runtime state.
4. **Inspect lock scope.** For state machines, acquire the singleton/process lock before lane and state reads and hold it through claim, external action, logging, and durable state publication. For hash-chained JSONL, hold one writer lock across load → validate → previous-hash selection → append → flush/fsync.
5. **Test process concurrency, not only threads.** Thread tests can pass while separate schedulers or cron processes still race. Run a bounded multi-process append probe against an external temp directory and reload the complete chain afterward.
6. **Distinguish corruption safety from observability.** An unlocked best-effort activity stream may tolerate skipped malformed rows; authoritative state, dispatch claims, approvals, and provider receipts may not. Rate defects according to which evidence class is affected.
7. **Keep verification read-only.** Disable bytecode/cache output, use an external pytest `--basetemp`, never run a side-effecting production entrypoint, and recheck staged/unstaged status afterward.

A credible `PASS` requires both static absence/reachability evidence and a focused executable probe. Passing unit tests alone do not establish that provider authority is closed or that cross-process serialization works.

## Reporting

Return `PASS` or `BLOCK`. Rank findings by execution/safety impact, then silent evidence corruption, then research/test reliability. Every finding needs staged `file:line`, mechanism, consequence, and the smallest precise fix. Separate verification evidence from findings and state any limitations. For a clean review, keep the final concise: verdict, boundary proved, verification results, and confirmation that no files were changed.