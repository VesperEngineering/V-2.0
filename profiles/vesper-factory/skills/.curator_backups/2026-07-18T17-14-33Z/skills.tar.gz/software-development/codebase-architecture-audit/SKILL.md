---
name: codebase-architecture-audit
description: Read-only architecture audit of a complex subsystem — map signal paths, trace caller chains with exact line numbers, cross-reference policy declarations against actual code consumption, identify duplicate/dead implementations, rate severity, and deliver the smallest trustworthy architecture with minimal safe next actions.
---

# Codebase Architecture Audit

Trigger when the user asks for a read-only audit of a subsystem (portfolio, risk, data pipeline, execution, etc.) and wants exact paths, line ranges, caller evidence, severity ratings, and minimal safe next actions. Also trigger for phrases like "map the X layer," "trace the Y path," "identify dead/duplicate Z," or "find the smallest trustworthy architecture above factors."

## Prerequisites

Before starting any audit:

1. **Read project governance docs first.** Every repo with formal governance has an AGENTS.md, a policy hierarchy doc, and a board/tracker. Read them ALL before touching code — they tell you what's active, what's retired, what's gated, and what naming is legacy vs. current. Skipping this step produces an audit that contradicts the project's own source of truth.

2. **Identify the active policy hierarchy.** Read the repository's current authority chain from its canonical governance documents and machine-readable manifests. Treat retired documents, historical plans, archived receipts, and compatibility names as non-authoritative unless the active hierarchy explicitly incorporates them. The audit must evaluate code against current policy, not stale naming or former frameworks.

3. **Distinguish "registered without a current lane" from "dead."** A domain that appears in the program registry but has no active lane is a gap — not dead code. Dead code has no caller, no import, or an explicit runtime guard blocking execution.

## Audit Methodology

### Phase 1: Surface Mapping (broad, fast)

1. **Read the project board/tracker** for the subsystem's registered status, active lanes, approved scope, and current execution authority.
2. **File-name discovery** — `search_files` with broad patterns (`*portfolio*`, `*risk*`, `*alloc*`, `*sizing*`, `*covariance*`, `*turnover*`, `*sector*`, `*concentration*`, `*drawdown*`) across the entire repo. Do all patterns in one parallel call.
3. **Directory enumeration** — `find` or `ls -la` on `app/services/`, `scripts/`, `deploy/`, and any factor/signal directories. Get the full file list before drilling into individual files.
4. **TODO list** — create a todo list with the major audit dimensions (signal paths, sizing, covariance, turnover, costs, sector/beta/concentration, drawdown, execution handoff, duplicates, architecture). Mark them off as each is validated.

### Phase 2: Deep Trace (one dimension at a time)

For each dimension in the audit:

1. **Read the primary file** (e.g., `intent_portfolio.py` for portfolio construction). Read in chunks if >200 lines — use `offset` and `limit` to page through.
2. **Follow every import** — for each `from app.services.X import Y`, verify X exists. If it doesn't appear in `search_files` results, broaden the search (worktrees, different naming).
3. **Cross-reference policy declarations vs. code consumption.** For every config knob declared in a policy dataclass, search for where it's actually read and consumed. Mark "declared, never consumed" as an orphaned configuration — this is a HIGH severity finding.
4. **Record exact line ranges** for:
   - The function/method that implements the behavior
   - The caller that invokes it
   - The policy/config that governs it
   - The gate/validator that enforces it
5. **Run parallel reads** — when you need to inspect multiple independent files, batch them in one turn. Serialize only when a later read depends on an earlier read's content.

### Phase 3: Duplicate and Dead Identification

For each file in the subsystem:

1. **Caller search** — `search_files` with `target='content'` for the file's module name or key function names. If no callers outside its own test file, mark as "no external callers."
2. **Runtime guard check** — read the entry point (`main()`, `if __name__` block, or key function). If it raises `RuntimeError`, calls `SystemExit`, or has an early return with a disabled message, it's definitively dead.
3. **Duplicate detection** — when two files implement the same algorithm (e.g., sector-neutral selection, factor z-scoring), flag both with the exact line ranges and note any parameter differences (ddof, window length, ticker filtering).
4. **Version chaining** — when files are named v1, v2, v3, determine which is current and which are superseded. Superseded versions that share no callers with the active path are legacy.

### Phase 4: Architecture Synthesis

1. **Draw the active path** as a linear chain from data source to execution handoff, with each node labeled by file and primary function.
2. **Identify the smallest trustworthy subgraph** — the minimal set of files that, if everything else were deleted, would still constitute a working, fail-closed system.
3. **List what to remove** (dead code, orphaned config, superseded versions) and **what to add** (missing wiring, missing controls) with explicit preconditions.
4. **Severity ratings:**
   - **CRITICAL:** Would cause incorrect execution, silent data loss, or authority bypass if triggered.
   - **HIGH:** Currently safe (guarded or single-symbol) but would become critical at the next scale-up.
   - **MEDIUM:** Creates operator confusion, technical debt, or maintenance risk.
   - **LOW:** Cosmetic, well-contained, or accepting current constraints by design.

### Phase 5: Report Format

Deliver the audit as a structured markdown report with:

1. Header: auditor role, date, scope, constraints
2. Numbered sections for each major dimension
3. Tables with columns: Implementation | Location | Lines | Mechanism/Status
4. Severity callouts in **bold** with rationale
5. ASCII architecture diagram for the active path
6. "Minimal Safe Next Actions" table with Priority | Action | Risk | Precondition
7. Explicit conclusion paragraph

## Whole-Stack / Stackflow Inventories

When the user asks for the current stack, stackflow, APIs, AI sources, agents, technology, workflow, or “everything,” use `references/whole-stack-current-state-inventory.md`.

Key rules:

1. Classify every component as **declared**, **configured**, **installed**, **active**, **evidence-producing**, or **historical/retired**. Do not collapse these states.
2. Inspect external runtime authority in addition to repository intent: provider ledgers, Hermes profiles, live cron/OS scheduler state, service status, latest receipts, and scheduled-target existence.
3. Enumerate credential and environment-variable **names only**; never print values.
4. Build a contradiction matrix across board policy, guards, candidate producers, submitters, reconcilers, scheduler targets, operator-surface declarations, model profiles, and provider-call receipts.
5. Present one end-to-end flow and one clear recommendation. Avoid turning the report into a raw file inventory.

## Workforce and Autonomous-Loop Audit

When auditing a worker workforce, autonomous loop, or steward/coordinator:

1. Treat **role files, lane manifests, model-allocation tables, activity events, and provider ledgers as separate evidence classes**. A declared owner or model allocation is not a worker invocation; a delegation event is not worker start; a successful receipt is not proof of an AI call unless it carries provider/request identity.
2. Trace each lane action to a concrete handler. For `delegate_to_*` or equivalent signals, require an actual process/session launcher, prompt/input construction, provider request, worker artifact, and terminal receipt. If the coordinator only persists a claim and emits activity, classify dispatch as **signal-only**.
3. Search for real model-call primitives and their callers (`responses.create`, `chat.completions`, provider SDK calls, Codex/Claude process launches, HTTP inference clients). Model names in a quota router or manifest are declarative until one is reachable from the lane entrypoint.
4. Separate lifecycle evidence: `delegated` → `started/active` → `working` → `completed/failed`. Require fresh timestamps or leases for active state, and require an artifact/receipt plus passing verification before accepting completion.
5. Audit retries explicitly: identify retry count, backoff, idempotency key, timeout lease, completion transition, and retry suppression. A permanent `claimed` bit without timeout or reconciliation is not a reliable retry system.
6. Inspect the live scheduler authority separately from repository intent: Windows Task Scheduler definitions, user-level automation directories, service/startup wrappers, working directories, and last-result evidence. For every installed task, compare its actual command, arguments, and working directory with the checked-in runner; verify that the exact target exists and report a nonzero Last Result separately from configured `Ready` status. A registry document or checked-in task XML that says an automation exists is descriptive, not proof it is installed or runnable.
7. When task/worker JSONL state exists, trace its in-repo writers and readers separately. Require a binding among steward packet ID, durable task ID, worker identity, provider request ID, artifact, validator, and review outcome. A task ledger or provider receipt with no reachable repository writer is externally produced evidence, not a verified coordinator execution path.
8. For real-LLM viability, require one harmless end-to-end proof through the exact chain `coordinator → launcher → model → artifact → validator → receipt`, preferably with a fake transport for timeout/malformed-response tests before any credentialed run.

## Git Worktree, Integration, And Shipping Audits

When the requested subsystem includes Git worktrees, branches, merge controls, CI, approvals, or deployment/shipping, add this evidence matrix before drawing conclusions:

1. **Snapshot Git state without mutation.** Capture `git status --short`, current branch/root, `git worktree list --porcelain`, local branch/upstream topology, and recent merge commits. Treat a worktree plan or contributor guidance as **declared process** unless an executable runner or current Git state proves it is active.
2. **Separate isolation from integration.** Multiple linked worktrees prove concurrent isolation, not a merge queue, integration branch, conflict resolver, or post-merge gate. Search executable non-document files for Git mutation/conflict primitives; report a policy-only process as manual rather than automated.
3. **Trace CI coverage from workflow commands, not test-file existence.** Extract the exact test paths and validators invoked by each workflow, then compare them with the relevant integration, scheduler, safety-guard, and deployment tests present in the repository. A green narrow CI lane is not evidence that absent critical suites ran.
4. **Trace approval end-to-end.** A manifest field such as `requires_operator_approval` is descriptive until the execution-capable function consumes a bound, authenticated approval record. Follow the action from CLI/UI entrypoint through approval consumer, scope/freshness checks, and final side effect. If a decision ledger always fails execution or is never called by the submitter, classify approval as recorded-but-non-authorizing.
5. **Inspect live scheduler/deployment state separately, read-only.** Compare tracked templates/installers with the installed task/service action path, working directory, enabled state, next/last run, and last result. A task targeting a runtime snapshot rather than the audited checkout is deployment drift. Do not infer the cause of an exit code without the corresponding logs.
6. **State external-control uncertainty precisely.** If branch protection, environment approvals, or release controls cannot be read through the available API/account, say **unverified**, not absent. Likewise distinguish no tracked release workflow from a possible external release process.

## Gated Multi-Agent Software-Delivery Audits

When auditing a proposed Planner → Build → gates → independent review → ship workflow, audit the execution graph rather than role names or design documents.

1. **Freeze the audit boundary first.** Capture branch, `git status --short`, worktree inventory, board/task state, active profiles, and existing untracked artifacts. Do not run tests or commands that write artifacts when the user requires a no-modification audit; inspect prior receipts and CI definitions instead.
2. **Trace one real task chain.** Start from a planner card, then inspect builder workspace/branch, gate commands and their recorded exits, reviewer task, rejection/rework linkage, and final authority. A manually completed chain proves primitives only; it does not prove a reusable state machine.
3. **Classify each required gate separately.** For every stage—planning, build, format, lint, type check, test, review, integration merge, post-merge test, approval, ship—state PRESENT, PARTIAL, MISSING, or PRESENT BUT UNSAFE. Cite the exact file/function/command/task event and the limiting condition.
4. **Bind every approval to immutable source identity.** Verify base SHA, candidate full SHA, diff/receipt hash, and reviewer identity. A short SHA prefix, branch name, mutable worktree, or task `done` status is not sufficient approval evidence.
5. **Separate isolation from orchestration.** A Git worktree proves only workspace separation. It does not prove component decomposition, safe parallel scheduling, conflict handling, staging merge control, or post-merge validation.
6. **Treat task budgets and retries as safety controls.** Inspect effective iteration budget, retry limit, lease/heartbeat, stale-run handling, idempotency, and escalation. A card that can start with a zero or invalid budget is a workflow reliability defect, not a harmless runtime detail.
7. **Trace failure routing, not just failure logging.** Exact formatter/linter/test output must reach the responsible builder; review rejection must select Planner only for an invalid approach and Builder for an implementation defect. If humans manually recreate cards or copy comments, classify routing as partial or unsafe.
8. **Trace Ship to a real side effect.** An approval ledger is only recorded intent until an execution-capable handler consumes a scope-bound, authenticated approval and produces an idempotent receipt. If execution intentionally fails closed, classify controlled ship as missing—not as active deployment support.
9. **Keep prototypes distinct from canonical capability.** Code present only on an unmerged branch or isolated worktree is a candidate/prototype. Do not count it as a canonical repository capability until the review and integration gates accept it.

## Pitfalls

- **Do not trust file-name search alone.** Files like `paper_application_policy.py` may live in `app/services/` but `search_files` with `path=D:/vesper/app` can fail due to Windows drive-path resolution. If `search_files` returns an implausible zero-file result, verify with a read-only terminal probe using the native drive path (`python` with `Path('D:/vesper').rglob(...)` or `os.walk('D:/vesper')`) before concluding the tree is empty. Do not substitute `/d/vesper` blindly: on some Windows shells the native `D:/vesper` path exists while `/d/vesper` does not.
- **Do not assume an imported module exists just because it's imported.** Python files in governed repos may import from modules that only exist in worktrees or were renamed. Verify every import with a file search.
- **Do not conflate "registered without a current lane" with "dead."** The project board may register a domain as a placeholder for future work — that's a gap, not dead code to be removed.
- **Do not treat research scripts as production.** Scripts like `factor_optimizer.py`, `signal_mine.py`, `dd_circuit_breaker.py` are research artifacts. Flag them as "research only, not integrated" — don't recommend deletion unless they're explicitly rejected in a design doc.
- **Do not skip the governance docs.** An audit that doesn't account for the project's own policy hierarchy will flag false positives and miss real gaps.
- **Do not run a broad suite as the only proof of an autonomous worker.** Use focused coordinator/ledger/receipt tests first; report unrelated stale-contract failures separately rather than treating them as worker-runtime evidence.

## Staged-Diff Reviews

For large read-only staged-diff correctness reviews, also consult `references/staged-diff-correctness-review.md`. It covers Git-index isolation, producer-to-consumer status tracing, calendar/portfolio assumptions, state-machine races, test expectation laundering, and read-only verification.

## Verification

After delivering the audit:
1. Confirm every severity rating has a rationale tied to specific code evidence.
2. Confirm the "smallest trustworthy architecture" can be traced end-to-end with no missing links.
3. Confirm dead-code identifications include caller evidence (or the absence of callers).
4. Confirm next actions are minimal, reversible, and gated by explicit preconditions.