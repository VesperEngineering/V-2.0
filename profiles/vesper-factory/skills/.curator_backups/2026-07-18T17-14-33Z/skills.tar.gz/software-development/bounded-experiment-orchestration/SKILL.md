---
name: bounded-experiment-orchestration
description: Run continuous, reproducible GPU research batches with fail-closed gates, durable receipts, and a truthful terminal HUD.
version: 1.0.0
---

# Bounded Experiment Orchestration

Use for exploratory ML/data research that should run autonomously for hours while preserving scientific discipline, reproducibility, and user visibility.

## Core separation

Separate two loops:

1. **Continuous compute:** fixed seeds, fixed parameter matrices, and fixed baselines may run back-to-back on the GPU.
2. **Research decisions:** deciding a new hypothesis is gated by prior evidence; never let a runner invent hypotheses, retune after results, or re-open an examined holdout.

## Required artifacts for every experiment

- Standalone numbered script.
- Frozen protocol/manifest entry before execution.
- Unbuffered phase logs: data admission, training, embedding extraction, evaluation, statistics, result write, done.
- Machine-readable JSON result artifact.
- Markdown research-log verdict: `VALIDATED`, `PARTIAL`, `INVALIDATED`, or `BLOCKED`.
- Explicit scope and non-production boundary.

## Queue design

Use a manifest as the sole source of truth. Each item must have: ID, question, dependency IDs, script, artifact path, primary metric, stop rule, and status (`PENDING`, `RUNNING`, `COMPLETE`, `BLOCKED`).

A queue worker may lease one dependency-ready item at a time. It must stop on nonzero exit, missing artifact, failed guard, or ambiguity; write a receipt; and never mutate parameters or create work items. Use cron only as a watchdog, never as a second worker.

## Scientific guardrails

- Compare neural representation against simple baselines before adding architecture complexity (e.g., PCA and linear autoencoder).
- Treat a single neural coordinate as non-identifiable: sign flips and rotations across random seeds are expected. Test full-subspace probes or alignment, not `dimension N means X` claims.
- Report every predeclared parameter-matrix row; do not select/tune from an already viewed evaluation period.
- Distinguish ordering/correlation from calibrated-level forecasting. A strong correlation plus strongly negative R² is descriptive state structure, not a usable forecast.

## Terminal HUD

Keep it compact and boring: top-line current script/phase/GPU, a small network diagram, evidence bars with actual values, current/queued matrix rows, and recent activity. Do not invent progress, fake green states, or bury the model diagram below the fold.

Use a terminal live renderer/alternate screen rather than manual clear-screen redraw loops. Keep the last artifacts visible after completion.

## Interactive operator workflow

When the experiment runs in a user-owned terminal that the agent cannot directly access:

1. State the boundary plainly; do not imply that the agent can inspect or edit that terminal.
2. When directory movement is required, put the navigation command first. Then give one exact command block at a time and wait for the user’s output before issuing dependent commands.
3. Never make the user paste Python source, shell prompts, PowerShell prompts, or transcript text into a shell. Clearly distinguish source edits from commands that apply edits.
4. Keep Windows/PowerShell and WSL/Linux instructions separate. If a prompt shows `>>`, first recover with `Ctrl+C`; from PowerShell, enter only `wsl`; then `cd` into the WSL-native project path.
5. After every patch, verify the exact lines before running a long experiment. Run a syntax/compile check before a five-minute GPU run.
6. Preserve the user’s current working configuration; do not silently switch from a chosen patching method to an editor or rewrite the approach mid-step.
7. For long Markdown/config contracts with nested fences, hashes, or literal tabs, create an actual host-visible file instead of relying on rendered chat. Read it back completely, hash it, and provide one copy command into the target workspace; preserve the upstream file and review the domain copy separately.

## Adapting reference research repositories

Before setup, inspect whether the upstream project is a reusable framework or a self-contained experiment driven by an external agent. State explicitly whether the plan will run upstream as written, use it as a template, or recreate its pattern in the target project. Never describe a custom domain adaptation as the upstream repository’s documented workflow.

For template ports, preserve the upstream control surface and distinguish two phases explicitly: (1) a one-time reviewed domain bootstrap that replaces domain-specific data/evaluation, baseline trainer, and dependencies; (2) the steady-state autonomous loop, where the human-authored instruction file is fixed and the external coding agent edits only the declared experiment file. Do not silently replace an external-agent loop with a Python grid or hardcoded mutation list; inspect loop ownership in generated files before claiming the adaptation is source-faithful.

When the user wants to inspect and edit an instruction file collaboratively, read the exact upstream revision yourself instead of asking them to paste a long terminal/editor transcript. Preserve the original, edit a review copy, and compare a diff before replacement. On WSL, a GUI editor may open the review copy with `notepad.exe "$(wslpath -w <file>)"`; make clear that the editor is optional and that Markdown belongs in the editor, not at the Bash prompt.

Verify the installed coding-agent CLI with `--help` before giving launch flags. Launch the agent first, wait until its interface is visibly open, and only then provide the natural-language prompt; otherwise users may paste Markdown into Bash. If this boundary is uncertain, stop before any autonomous writes.

See `references/autonomous-research-repo-adaptation.md` for the repository-classification checklist, Karpathy autoresearch structural audit, and version-specific Codex launch notes.

## GPU-port and kernel compatibility

Treat upstream hardware assumptions as part of the protocol. A precompiled attention kernel can fail on a newer GPU with `no kernel image is available for execution on the device`; this is a compatibility failure, not a model-quality result. Establish a tight smoke-test reproduction, then use a supported PyTorch native `scaled_dot_product_attention` fallback when the configured kernel lacks the GPU architecture. Verify tensor layout (`[B,T,H,D]` to `[B,H,T,D]` and back) and run `py_compile` before training.

For a smaller GPU, start with a conservative model/batch configuration, then change one hardware variable at a time. Keep the fixed wall-clock budget and record `val_bpb`, peak VRAM, tokens processed, and parameter count. Native SDPA may reduce throughput; the script’s H100-referenced MFU is not a trustworthy utilization measure for another GPU.

Keep gradient accumulation valid:

```text
TOTAL_BATCH_SIZE % (DEVICE_BATCH_SIZE * MAX_SEQ_LEN) == 0
```

If adapting upstream `prepare.py` (for example, shorter context or smaller evaluation), document that protocol deviation because comparisons are no longer identical to upstream. No model-provider API key is required when the training corpus is downloaded from the repository’s configured public dataset source.

## Fixed-budget interpretation

Under a fixed time budget, model capacity and throughput trade off directly. A deeper model can produce a worse validation metric if it processes substantially fewer tokens, even when it uses more VRAM. Select or retain configurations by the declared metric and protocol, not by memory utilization alone. When a trial is worse or OOMs, restore the last confirmed-good configuration and record the trial as discarded/crashed; do not continue tuning from an inferior state.

## Verification

Before reporting completion: compile scripts, verify the result artifact exists and parses, confirm the research log reflects the actual verdict, and check that no protected production path was modified.

See `references/jepa-research-lessons.md` for concrete lessons from a raw-OHLCV JEPA program. See `references/karpathy-autoresearch-blackwell.md` for the Blackwell/WSL2 compatibility and fixed-budget experiment notes.
