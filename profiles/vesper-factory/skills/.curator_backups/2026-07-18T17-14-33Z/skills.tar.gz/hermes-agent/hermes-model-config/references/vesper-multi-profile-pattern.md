# Vesper Multi-Profile Model Configuration Pattern

Documented from user's production setup (July 2026). Shows how to configure a multi-worker agent fleet with tiered model assignments using OpenAI Codex (OAuth) as primary and OpenRouter as fallback.

## Profile Fleet Overview

| Profile | Role | Model | Provider | Reasoning | Fallback |
|---------|------|-------|----------|-----------|----------|
| `vesper-thomas` | Strategy / Architecture | `gpt-5.6-sol` | **OpenAI Codex** | high | gemini-2.5-flash, ollama |
| `vesper-engineer` | Engineering / Coding | `gpt-5.6-terra` | **OpenAI Codex** | medium | gemini-2.5-flash, ollama |
| `vesper-clarke` | Coordinator / Steward | `gpt-5.6-luna` | **OpenAI Codex** | low | deepseek-v4-flash |
| `vesper-steward` | Monitor / 24/7 ticks | `deepseek/deepseek-v4-flash` | **OpenRouter** (free) | low | gemini-2.5-flash, ollama |
| `vesper-morgan` | Specialist (factor research) | `gpt-5.6-luna` | **OpenAI Codex** | medium | gemini-2.5-flash, ollama |
| `vesper-rez` | Specialist (risk/portfolio) | `gpt-5.6-luna` | **OpenAI Codex** | medium | deepseek-v4-pro |
| `vesper-riley` | Specialist (execution/ops) | `gpt-5.6-luna` | **OpenAI Codex** | medium | gemini-2.5-flash |
| `default` | General chat / ad-hoc | `deepseek/deepseek-v4-flash` | **OpenRouter** | high | gemini-2.5-flash, ollama |

## Key Patterns

### 1. Codex Primary, OpenRouter Fallback
```yaml
model:
  default: gpt-5.6-sol          # Codex model name (no 'openai/' prefix)
  provider: openai-codex         # Uses OAuth via `hermes auth`
  fallback: google/gemini-2.5-flash,custom:ollama-local/qwen3:14b-ctx
  base_url: https://chatgpt.com/backend-api/codex
```

### 2. Reasoning Effort Matched to Role
- **high**: Strategy/architecture (Thomas) — deep reasoning worth the tokens
- **medium**: Engineering, specialists (Engineer, Morgan, Rez, Riley) — balanced
- **low**: Coordinators, monitors (Clarke, Steward) — routing/heartbeats don't need deep reasoning

### 3. Steward Stays on OpenRouter Free Tier
The 24/7 monitor (15-min ticks) uses `deepseek/deepseek-v4-flash` (free on OpenRouter) to avoid burning Codex subscription tokens on routine health checks.

### 4. Fallback Chain Design
- **Tier 1**: Codex primary (subscription, high priority, full context)
- **Tier 2**: OpenRouter cheap/free models (gemini-2.5-flash, deepseek-v4-flash)
- **Tier 3**: Local Ollama (offline, unlimited, privacy)

### 5. Per-Profile Config Location
```
~/.hermes/profiles/vesper-<name>/config.yaml
```

## Quick Commands

```bash
# List all profiles with models
hermes profile list

# Switch to a worker profile
hermes -p vesper-thomas

# View a profile's config
hermes -p vesper-thomas config

# Set model for a profile
hermes -p vesper-thomas config set model.default gpt-5.6-sol
hermes -p vesper-thomas config set model.provider openai-codex
hermes -p vesper-thomas config set model.fallback "google/gemini-2.5-flash,custom:ollama-local/qwen3:14b-ctx"
hermes -p vesper-thomas config set agent.reasoning_effort high
```

## Cost/Performance Rationale

| Tier | Monthly Cost | Use Case |
|------|--------------|----------|
| Codex (Pro/Plus) | Included in sub | Primary workers — reasoning, coding, strategy |
| OpenRouter paid | ~$5-20/mo | Fallback, Steward monitor |
| OpenRouter free | $0 | Default chat, backup |
| Local Ollama | $0 (hardware) | Offline, privacy, unlimited |

The fleet costs ~$20/mo (ChatGPT Pro) + minimal OpenRouter fallback spend, vs $200+/mo for equivalent API-only usage.